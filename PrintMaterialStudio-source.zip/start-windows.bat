@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Print Material Studio
chcp 65001 >nul

echo ==========================================
echo   Print Material Studio - local launcher
echo ==========================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
  set "PYTHON=py -3"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (set "PYTHON=python") else (
    echo [ERROR] 未找到 Python 3。
    echo 请从 https://www.python.org/downloads/windows/ 安装 Python 3，安装时勾选 Add python.exe to PATH。
    goto :failed
  )
)

if not exist ".venv\Scripts\python.exe" (
  echo 正在创建本地 Python 环境...
  %PYTHON% -m venv .venv
  if errorlevel 1 (
    echo [ERROR] 创建 Python 环境失败。
    goto :failed
  )
)

echo 正在检查依赖...
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo [ERROR] 依赖安装失败。请检查网络，或把上面的错误信息发给我。
  goto :failed
)

echo.
echo 服务启动中，请在浏览器打开 http://127.0.0.1:8765
.venv\Scripts\python.exe run.py --no-browser --port 8765
if errorlevel 1 (
  echo.
  echo [ERROR] 服务启动失败。
  goto :failed
)
goto :eof

:failed
echo.
echo 按任意键关闭窗口...
pause >nul
exit /b 1
