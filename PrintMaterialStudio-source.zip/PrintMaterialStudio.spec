# Build on Windows: python -m PyInstaller --noconfirm PrintMaterialStudio.spec
from pathlib import Path

root = Path(SPECPATH)
a = Analysis(
    [str(root / 'desktop_launcher.py')],
    pathex=[str(root)],
    binaries=[],
    datas=[(str(root / 'print_studio' / 'static'), 'print_studio/static'),
           (str(root / 'dist' / 'preview.html'), 'dist')],
    hiddenimports=['pystray._win32'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['tkinter', 'pytest', 'playwright'],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name='PrintMaterialStudio', debug=False, bootloader_ignore_signals=False,
    strip=False, upx=False, console=False, disable_windowed_traceback=False,
)
