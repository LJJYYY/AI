# Windows 桌面版

下载 `PrintMaterialStudio-Windows-x64.zip`，完整解压，再双击 `PrintMaterialStudio.exe`。不需要安装 Python，不需要运行 bat/vbs，也不显示黑色命令窗口。支持 Windows 10/11 64 位。

首次解压后，可以右键程序 → 显示更多选项 → 发送到 → 桌面快捷方式。以后双击桌面图标即可自动打开工作台。无需以管理员身份运行。

程序图标在右下角系统托盘中；若看不到，请点托盘的向上箭头。右键图标可选择“打开工作台”“打开数据文件夹”“退出工作台”。关闭浏览器页面后，程序仍在托盘运行；选择“退出工作台”才会停止服务并释放端口。再次双击程序只打开已经运行的工作台。

默认地址为 `http://127.0.0.1:18765`。端口被占用时，程序会选择空闲端口并打开实际网址，使用桌面图标即可，不必记住网址。

## 数据与旧版迁移

桌面版把模板、商品、素材及设置保存在 `%LOCALAPPDATA%\PrintMaterialStudio\data`，升级 exe 不会删除这些文件。源码版的旧数据仍保存在原文件夹 `.local-data`，不会被桌面版自动覆盖或删除。

如果要沿用旧数据，先退出新旧两个版本，然后将旧项目的 `.local-data` 文件夹里的内容复制到上述桌面版数据目录；如桌面版已有新数据，请先备份目标目录再合并。若只需使用原数据目录，也可创建指向 `PrintMaterialStudio.exe --data-dir "D:\原项目\.local-data"` 的快捷方式。

## 开发者构建与验证

Windows 下用 Python 3.12 执行：

```text
python -m pip install -r requirements-desktop.txt
python -m unittest discover -s tests -q
python -m PyInstaller --noconfirm PrintMaterialStudio.spec
python scripts/check_desktop_binary.py dist/PrintMaterialStudio.exe
```

Windows 构建检查实际 exe 的启动、端口冲突避让、静态资源、布局识别、重复启动复用及退出释放。Linux 测试验证同一服务生命周期；不能代替 Windows exe 验证。
