from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]
out=root/'dist'/'PrintMaterialStudio-source.zip'
out.parent.mkdir(exist_ok=True)
files=['run.py','start-windows.bat','start-windows-hidden.vbs','desktop_launcher.py','PrintMaterialStudio.spec','README.md','requirements.txt','requirements-dev.txt','requirements-desktop.txt','print_studio/__init__.py','print_studio/app.py','print_studio/desktop.py','print_studio/provider.py','print_studio/texture.py','print_studio/layout_analysis.py','print_studio/static/index.html','print_studio/static/style.css','print_studio/static/app.js','docs/print-material-tool-requirements.md','docs/windows-desktop.md','docs/examples/confirmed-layout.json','dist/preview.html','scripts/build_preview.py','scripts/package_local.py','scripts/check_layout_browser.py','scripts/check_desktop_binary.py','tests/test_studio.py','tests/test_layout_analysis.py']
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for name in files:
        p=root/name
        if p.exists(): z.write(p,name)
print(out)
