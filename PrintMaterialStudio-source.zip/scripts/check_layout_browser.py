"""Exercise real layout upload/reanalysis routes with isolated data and Chromium.

Fixtures are synthetic; this does not claim validation against a chat-only photo.
"""
import json
import os
import sys
import tempfile
import threading
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from PIL import Image
from playwright.sync_api import sync_playwright
import print_studio.app as app
from test_layout_analysis import pink_sheet


def run():
    os.environ['PRINT_STUDIO_QUIET']='1'
    with tempfile.TemporaryDirectory() as temporary:
        data=Path(temporary)
        fixture=data/'XGN-pink-6270.jpg';fixture.write_bytes(pink_sheet()[0])
        blank=data/'white.png';Image.new('RGB',(600,800),'white').save(blank)
        settings={'DATA_ROOT':data/'store','PRODUCT_ROOT':data/'store/products','OUTPUT_ROOT':data/'store/outputs',
                  'LAYOUT_ROOT':data/'store/template-layouts','TEMPLATE_FILE':data/'store/templates.json',
                  'JOB_FILE':data/'store/jobs.json','SETTINGS_FILE':data/'store/settings.json'}
        with patch.multiple(app,**settings):
            app.ensure_data()
            server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            url=f'http://127.0.0.1:{server.server_port}'
            try:
                with sync_playwright() as playwright:
                    browser=playwright.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
                    page=browser.new_page(viewport={'width':1600,'height':1100})
                    errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
                    page.goto(url,wait_until='networkidle')
                    assert page.locator('#layout-svg .part').count()==12
                    page.set_input_files('#template-file',str(fixture))
                    with page.expect_response(lambda r:r.url.endswith('/api/templates/analyze')) as event:
                        page.click('#analyze-layout')
                    result=event.value.json();draft_id=result['template']['id']
                    page.wait_for_function("document.querySelector('#part-count').textContent==='11 块'")
                    assert result['template']['layout_source']['analysis_method']=='layout-runs-v2'
                    assert page.locator('#layout-source-overlay rect').count()==11
                    assert page.locator('#part-list .part-item').count()==11
                    with page.expect_response(lambda r:r.url.endswith('/api/templates/analyze')) as event:
                        page.click('#analyze-layout')
                    assert event.value.json()['template']['id']==draft_id
                    assert page.locator('#template-select option').count()==2
                    page.click('#expand-layout-source')
                    screenshot='/tmp/layout-analysis-v2.png'
                    page.screenshot(path=screenshot,full_page=True)
                    with page.expect_response(lambda r:r.url.endswith('/api/templates') and r.request.method=='POST'):
                        page.click('#save-template')
                    page.reload(wait_until='networkidle')
                    assert page.locator('#layout-svg .part').count()==11
                    assert page.locator('#template-file').evaluate('(input)=>input.files.length')==0
                    with page.expect_response(lambda r:r.url.endswith('/api/templates/analyze')) as event:
                        page.click('#analyze-layout')
                    assert len(event.value.json()['template']['parts'])==11
                    page.set_input_files('#template-file',str(blank))
                    with page.expect_response(lambda r:r.url.endswith('/api/templates/analyze')) as event:
                        page.click('#analyze-layout')
                    assert event.value.json()['template']['parts']==[]
                    page.wait_for_function("document.querySelector('#part-count').textContent==='0 块'")
                    assert page.locator('#layout-svg .part').count()==0
                    assert page.locator('#confirm-template').is_disabled()
                    assert not errors,errors
                    browser.close()
                    print(json.dumps({'upload_candidates':11,'reanalysis_same_draft':True,'reload_reanalysis':True,'empty_does_not_restore_xgv':True,'page_errors':errors,'screenshot':screenshot}))
            finally:
                server.shutdown();server.server_close();thread.join()

if __name__=='__main__':run()
