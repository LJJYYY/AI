from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'print_studio/static/index.html').read_text(encoding='utf-8')
css=(root/'print_studio/static/style.css').read_text(encoding='utf-8')
js=(root/'print_studio/static/app.js').read_text(encoding='utf-8')
html=html.replace('<meta name="print-studio-runtime" content="server">','<meta name="print-studio-runtime" content="preview">')
html=html.replace('<link rel="stylesheet" href="/static/style.css">',f'<style>{css}</style>').replace('<link rel="stylesheet" href="/static/style.css?v=layout-runs-v2">',f'<style>{css}</style>')
html=html.replace('<script src="/static/app.js"></script>',f'<script>{js}</script>').replace('<script src="/static/app.js?v=layout-runs-v2"></script>',f'<script>{js}</script>')
(root/'dist').mkdir(exist_ok=True)
(root/'dist/preview.html').write_text(html,encoding='utf-8')
print(root/'dist/preview.html')
