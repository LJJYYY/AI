"""Verify task export and placeholder rejection through the actual browser UI."""
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from PIL import Image
from playwright.sync_api import sync_playwright
import print_studio.app as app
from test_handoff import picture


def run():
    os.environ['PRINT_STUDIO_QUIET'] = '1'
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        product = root / 'source.png'; product.write_bytes(picture())
        plain = root / 'placeholder.png'; Image.new('RGB', (1536, 1536), '#345678').save(plain)
        data = root / 'store'
        settings = {'DATA_ROOT': data, 'PRODUCT_ROOT': data / 'products', 'OUTPUT_ROOT': data / 'outputs',
                    'LAYOUT_ROOT': data / 'template-layouts', 'TEMPLATE_FILE': data / 'templates.json',
                    'JOB_FILE': data / 'jobs.json', 'SETTINGS_FILE': data / 'settings.json'}
        with patch.multiple(app, **settings):
            app.ensure_data()
            server = ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
            try:
                with sync_playwright() as playwright:
                    browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
                    context = browser.new_context(viewport={'width': 1600, 'height': 1100}, accept_downloads=True)
                    context.route('https://chatgpt.com/**', lambda route: route.fulfill(body='ChatGPT navigation intercepted for test'))
                    page = context.new_page()
                    errors = []; page.on('pageerror', lambda error: errors.append(str(error)))
                    page.goto(f'http://127.0.0.1:{server.server_port}', wait_until='networkidle')
                    page.click('#layout-svg .part[data-id="04"]')
                    note = '口袋仅取本体，不包含手和袖口。'
                    page.locator('.part-item.selected .extraction-note').fill(note)
                    page.locator('.part-item.selected .extraction-note').press('Tab')
                    with page.expect_response(lambda r: r.url.endswith('/api/templates') and r.request.method == 'POST'):
                        page.click('#confirm-template')
                    page.click('.nav-link[data-tab="products"]')
                    page.set_input_files('#photo-files', str(product))
                    page.wait_for_function("document.querySelector('#product-count').textContent==='1 件'")
                    assert page.locator('#surface-part-id').input_value() == '04'
                    with page.expect_download() as download:
                        page.click('#export-chatgpt-task')
                    path = root / 'task.zip'; download.value.save_as(str(path))
                    with zipfile.ZipFile(path) as archive:
                        manifest = json.loads(archive.read('manifest.json'))
                        prompt = archive.read('prompt.txt').decode('utf-8')
                    assert manifest['part_id'] == '04'
                    assert manifest['part']['extraction_note'] == note
                    with page.expect_response(lambda r: r.url.endswith('/api/handoff/prompt')) as prompt_response:
                        with page.expect_popup() as popup:
                            page.click('#open-chatgpt-task')
                    popup.value.wait_for_url('https://chatgpt.com/**')
                    assert prompt_response.value.json()['prompt'] == prompt
                    assert parse_qs(urlsplit(popup.value.url).query)['q'][0] == prompt_response.value.json()['launch_prompt']
                    assert len(popup.value.url) < 6000
                    popup.value.close()
                    with page.expect_response(lambda r: r.url.endswith('/api/handoff/import')) as response:
                        page.set_input_files('#import-generated-result', str(plain))
                    assert response.value.status == 422
                    page.wait_for_function("document.querySelector('#handoff-status').textContent.includes('已阻止导入')")
                    assert not list(app.OUTPUT_ROOT.glob('material-*'))
                    page.check('#confirm-plain-source')
                    with page.expect_response(lambda r: r.url.endswith('/api/handoff/import')) as response:
                        page.set_input_files('#import-generated-result', str(plain))
                    assert response.value.status == 201 and response.value.json()['status'] == 'needs_review'
                    page.wait_for_function("!document.querySelector('#surface-preview').hidden")
                    assert page.locator('#approve-surface').is_enabled()
                    assert not errors, errors
                    page.screenshot(path='/tmp/handoff-source-evidence-v2.png', full_page=True)
                    print(json.dumps({'task_export': True, 'scope_saved': True, 'prefill_matches_zip': True,
                                      'flat_result_blocked': True, 'genuine_plain_needs_review': True, 'page_errors': errors}))
                    browser.close()
            finally:
                server.shutdown(); server.server_close(); thread.join()


if __name__ == '__main__':
    run()
