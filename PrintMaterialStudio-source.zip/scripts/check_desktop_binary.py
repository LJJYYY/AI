"""Smoke test the frozen Windows executable (or source launcher on Linux)."""
import json
from io import BytesIO
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import zipfile
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
HTTP = build_opener(ProxyHandler({}))


def upload(url, fields, field, content, filename='fixture.png'):
    boundary = 'desktop-upload-check-boundary'
    chunks = []
    for name, value in fields.items():
        chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    chunks += [f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; filename="{filename}"\r\nContent-Type: image/png\r\n\r\n'.encode(),
               content, f'\r\n--{boundary}--\r\n'.encode()]
    return HTTP.open(Request(url, data=b''.join(chunks), headers={'Content-Type': f'multipart/form-data; boundary={boundary}'}), timeout=20)


def check(command, tray=False):
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary) / 'data'
        runtime = directory / 'desktop-session.json'
        # Occupy a port using our own socket; do not stop another application.
        with socket.socket() as occupied:
            occupied.bind(('127.0.0.1', 0))
            occupied.listen()
            requested = occupied.getsockname()[1]
            if requested > 65525:
                requested = 18765
            args = command + ['--no-browser', '--data-dir', str(directory), '--port', str(requested)]
            if not tray:
                args.append('--headless')
            process = subprocess.Popen(args, cwd=ROOT)
            session = None
            try:
                deadline = time.monotonic() + 60
                while time.monotonic() < deadline:
                    assert process.poll() is None, (directory / 'desktop.log').read_text(encoding='utf-8') if (directory / 'desktop.log').exists() else 'Exited early'
                    try:
                        session = json.loads(runtime.read_text(encoding='utf-8'))
                        with HTTP.open(session['url'] + '/__desktop/health', timeout=1) as response:
                            if json.load(response)['instance'] == session['instance']:
                                break
                    except (OSError, URLError, ValueError):
                        pass
                    time.sleep(0.2)
                else:
                    raise AssertionError('Desktop service did not become ready')
                assert session['url'] != f'http://127.0.0.1:{occupied.getsockname()[1]}'
                assert subprocess.run(args, cwd=ROOT, timeout=45).returncode == 0
                assert json.loads(runtime.read_text(encoding='utf-8'))['pid'] == session['pid']
                assert process.poll() is None
                for path in ['/', '/static/app.js', '/static/style.css', '/api/templates', '/api/status']:
                    with HTTP.open(session['url'] + path, timeout=10) as response:
                        assert response.status == 200 and len(response.read()) > 0
                from PIL import Image, ImageDraw
                fixture = Image.new('RGB', (800, 600), 'white')
                draw = ImageDraw.Draw(fixture)
                draw.rectangle((20, 20, 180, 150), fill='#25364b')
                draw.rectangle((230, 40, 400, 240), fill='#6d8ca8')
                draw.rectangle((80, 320, 300, 560), fill='#a36a55')
                image = BytesIO()
                fixture.save(image, format='PNG')
                boundary = 'desktop-smoke-test-boundary'
                body = (f'--{boundary}\r\nContent-Disposition: form-data; name="layout"; filename="layout.png"\r\nContent-Type: image/png\r\n\r\n'.encode()
                        + image.getvalue() + f'\r\n--{boundary}--\r\n'.encode())
                request = Request(session['url'] + '/api/templates/analyze', data=body,
                                  headers={'Content-Type': f'multipart/form-data; boundary={boundary}'})
                with HTTP.open(request, timeout=20) as response:
                    assert len(json.load(response)['template']['parts']) == 3
                with HTTP.open(session['url'] + '/api/templates') as response:
                    template = json.load(response)[0]
                with upload(session['url'] + '/api/products', {'template_id': template['id']}, 'photos', image.getvalue()) as response:
                    product = json.load(response)
                task_payload = {'template_id': template['id'], 'scope': 'all', 'product_ids': [product['id']]}
                task_headers = {'Content-Type': 'application/json'}
                with HTTP.open(Request(session['url'] + '/api/handoff/package', data=json.dumps(task_payload).encode(), headers=task_headers)) as response:
                    task_archive = zipfile.ZipFile(BytesIO(response.read()))
                with HTTP.open(Request(session['url'] + '/api/handoff/prompt', data=json.dumps(task_payload).encode(), headers=task_headers)) as response:
                    prompt = json.load(response)['prompt']
                assert prompt == task_archive.read('prompt.txt').decode('utf-8')
                manifest = json.loads(task_archive.read('manifest.json'))
                assert manifest['task_version'] == 'all-parts-source-evidence-v3'
                assert manifest['total_tasks'] == len(template['parts']) == 12
                # A correctly sized solid placeholder must fail before creating output.
                plain = BytesIO(); Image.new('RGB', (1536, 1536), '#345678').save(plain, format='PNG')
                import_fields = {'template_id': template['id'], 'part_id': '04', 'product_id': product['id']}
                try:
                    upload(session['url'] + '/api/handoff/import', import_fields, 'result', plain.getvalue())
                    raise AssertionError('Flat placeholder was accepted')
                except HTTPError as error:
                    assert error.code == 422
                assert not list((directory / 'outputs').glob('material-*'))
                with upload(session['url'] + '/api/handoff/import', {**import_fields, 'plain_source_confirmed': 'true'}, 'result', plain.getvalue()) as response:
                    imported = json.load(response)
                assert imported['status'] == 'needs_review'
                assert not (directory / 'outputs' / imported['id'] / 'material.jpg').exists()
                output_file = f"materials/{product['id']}/05.jpg"
                result_zip = BytesIO()
                patterned = BytesIO(); fixture.resize((1536,1536)).save(patterned, format='JPEG')
                with zipfile.ZipFile(result_zip, 'w') as archive:
                    archive.writestr(output_file, patterned.getvalue())
                    archive.writestr('result-report.json', json.dumps({'results': [{
                        'product_id': product['id'], 'part_id': '05', 'status': 'completed',
                        'output_file': output_file, 'source_file': manifest['products'][0]['images'][0]['file'],
                        'source_region': 'synthetic test image'}]}))
                with upload(session['url'] + '/api/handoff/import-batch', {'task': json.dumps(task_payload)}, 'result', result_zip.getvalue(), 'results.zip') as response:
                    batch = json.load(response)
                assert batch['total'] == 12 and batch['imported'] == 1 and batch['needs_attention'] == 11
                try:
                    HTTP.open(Request(session['url'] + '/__desktop/quit', data=b''), timeout=5)
                    raise AssertionError('Unauthenticated quit was accepted')
                except HTTPError as error:
                    assert error.code == 403
                stopped = subprocess.run(command + ['--quit', '--data-dir', str(directory)], cwd=ROOT, timeout=45)
                assert stopped.returncode == 0
                process.wait(timeout=15)
                assert process.returncode == 0 and not runtime.exists()
                assert (directory / 'templates.json').exists()
                from urllib.parse import urlsplit
                with socket.socket() as released:
                    released.settimeout(2)
                    assert released.connect_ex(('127.0.0.1', urlsplit(session['url']).port)) != 0
                from print_studio.desktop import InstanceLock
                lock = InstanceLock(directory / 'desktop.lock')
                assert lock.acquire(), 'Single-instance lock was not released'
                lock.release()
                print(json.dumps({'desktop_lifecycle': 'passed', 'tray': tray, 'conflict_avoided': True,
                                  'duplicate_reused': True, 'port_released': True,
                                  'handoff_prompt_matches_package': True, 'flat_placeholder_blocked': True,
                                  'all_parts_export': True, 'batch_import_matches_parts': True}))
            finally:
                if process.poll() is None:
                    process.terminate()
                    process.wait(timeout=10)


if __name__ == '__main__':
    if len(sys.argv) > 1:
        check([str(Path(sys.argv[1]).resolve())], tray=True)
    else:
        check([sys.executable, str(ROOT / 'desktop_launcher.py')])
