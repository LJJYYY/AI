"""Smoke test the frozen Windows executable (or source launcher on Linux)."""
import json
from io import BytesIO
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
HTTP = build_opener(ProxyHandler({}))


def check(command, tray=False):
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary) / 'data'
        runtime = directory / 'desktop-session.json'
        # Occupy a port using our own socket; do not stop another application.
        with socket.socket() as occupied:
            occupied.bind(('127.0.0.1', 0))
            occupied.listen()
            requested = occupied.getsockname()[1]
            if requested > 65525:
                requested = 18765
            args = command + ['--no-browser', '--data-dir', str(directory), '--port', str(requested)]
            if not tray:
                args.append('--headless')
            process = subprocess.Popen(args, cwd=ROOT)
            session = None
            try:
                deadline = time.monotonic() + 60
                while time.monotonic() < deadline:
                    assert process.poll() is None, (directory / 'desktop.log').read_text(encoding='utf-8') if (directory / 'desktop.log').exists() else 'Exited early'
                    try:
                        session = json.loads(runtime.read_text(encoding='utf-8'))
                        with HTTP.open(session['url'] + '/__desktop/health', timeout=1) as response:
                            if json.load(response)['instance'] == session['instance']:
                                break
                    except (OSError, URLError, ValueError):
                        pass
                    time.sleep(0.2)
                else:
                    raise AssertionError('Desktop service did not become ready')
                assert session['url'] != f'http://127.0.0.1:{occupied.getsockname()[1]}'
                assert subprocess.run(args, cwd=ROOT, timeout=45).returncode == 0
                assert json.loads(runtime.read_text(encoding='utf-8'))['pid'] == session['pid']
                assert process.poll() is None
                for path in ['/', '/static/app.js', '/static/style.css', '/api/templates', '/api/status']:
                    with HTTP.open(session['url'] + path, timeout=10) as response:
                        assert response.status == 200 and len(response.read()) > 0
                from PIL import Image, ImageDraw
                fixture = Image.new('RGB', (800, 600), 'white')
                draw = ImageDraw.Draw(fixture)
                draw.rectangle((20, 20, 180, 150), fill='#25364b')
                draw.rectangle((230, 40, 400, 240), fill='#6d8ca8')
                draw.rectangle((80, 320, 300, 560), fill='#a36a55')
                image = BytesIO()
                fixture.save(image, format='PNG')
                boundary = 'desktop-smoke-test-boundary'
                body = (f'--{boundary}\r\nContent-Disposition: form-data; name="layout"; filename="layout.png"\r\nContent-Type: image/png\r\n\r\n'.encode()
                        + image.getvalue() + f'\r\n--{boundary}--\r\n'.encode())
                request = Request(session['url'] + '/api/templates/analyze', data=body,
                                  headers={'Content-Type': f'multipart/form-data; boundary={boundary}'})
                with HTTP.open(request, timeout=20) as response:
                    assert len(json.load(response)['template']['parts']) == 3
                try:
                    HTTP.open(Request(session['url'] + '/__desktop/quit', data=b''), timeout=5)
                    raise AssertionError('Unauthenticated quit was accepted')
                except HTTPError as error:
                    assert error.code == 403
                stopped = subprocess.run(command + ['--quit', '--data-dir', str(directory)], cwd=ROOT, timeout=45)
                assert stopped.returncode == 0
                process.wait(timeout=15)
                assert process.returncode == 0 and not runtime.exists()
                assert (directory / 'templates.json').exists()
                from urllib.parse import urlsplit
                with socket.socket() as released:
                    released.settimeout(2)
                    assert released.connect_ex(('127.0.0.1', urlsplit(session['url']).port)) != 0
                from print_studio.desktop import InstanceLock
                lock = InstanceLock(directory / 'desktop.lock')
                assert lock.acquire(), 'Single-instance lock was not released'
                lock.release()
                print(json.dumps({'desktop_lifecycle': 'passed', 'tray': tray, 'conflict_avoided': True,
                                  'duplicate_reused': True, 'port_released': True}))
            finally:
                if process.poll() is None:
                    process.terminate()
                    process.wait(timeout=10)


if __name__ == '__main__':
    if len(sys.argv) > 1:
        check([str(Path(sys.argv[1]).resolve())], tray=True)
    else:
        check([sys.executable, str(ROOT / 'desktop_launcher.py')])
