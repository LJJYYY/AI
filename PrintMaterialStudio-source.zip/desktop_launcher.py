"""Windowless entry point used by the Windows executable."""
from print_studio.desktop import main


if __name__ == "__main__":
    raise SystemExit(main())
