"""Regressions for light/pink nesting sheets, narrow gaps and failed analyses."""
import io
import unittest
from PIL import Image, ImageDraw
from print_studio.app import template_parts_from_layout
from print_studio.layout_analysis import detect_layout_regions


def pink_sheet():
    # Original scale comparable to the reported 6270x6865 JPG. Pieces touch the
    # sheet edge and have gaps that the old 420px+dilation pipeline erased.
    image=Image.new('RGB',(6270,6865),'white')
    draw=ImageDraw.Draw(image)
    boxes=[]
    for row in range(2):
        for col in range(5):
            x=col*1256;y=row*3320
            box=(x,y,x+1245,y+3305)
            draw.rectangle(box,fill='#d58c96',outline='#202025',width=4)
            # Cream print stays inside the piece and is not treated as paper.
            for px in range(x+40,x+1200,120):
                draw.ellipse((px,y+100,px+70,y+170),fill='#f1d6bd')
            boxes.append(box)
    box=(0,6652,3000,6864)
    draw.rectangle(box,fill='#d58c96',outline='black',width=4)
    boxes.append(box)
    # Detached barcode/size label: its sparse ink should not become a garment.
    draw.rectangle((3800,6690,4050,6830),outline='black',width=3)
    data=io.BytesIO();image.save(data,'JPEG',quality=92)
    return data.getvalue(),boxes


class LayoutAnalysisTests(unittest.TestCase):
    def test_high_resolution_gaps_border_and_sparse_label(self):
        data,expected=pink_sheet()
        parts,metadata=template_parts_from_layout(data)
        self.assertEqual(len(parts),11)
        self.assertEqual(metadata['analysis_method'],'layout-runs-v2-packed')
        self.assertEqual((metadata['width'],metadata['height']),(6270,6865))
        self.assertEqual(max(metadata['analysis_width'],metadata['analysis_height']),2400)
        for part,box in zip(parts,expected):
            for actual,target in zip(part['source_box'],box):
                self.assertLessEqual(abs(actual-target),8)
        self.assertTrue(all(p['role'].startswith('piece-') for p in parts))

    def test_empty_or_unsegmented_never_uses_old_twelve_parts(self):
        for color in ('white','#c68a95'):
            image=Image.new('RGB',(600,800),color)
            buffer=io.BytesIO();image.save(buffer,'PNG')
            parts,metadata=template_parts_from_layout(buffer.getvalue())
            self.assertEqual(parts,[])
            self.assertEqual(metadata['detected_count'],0)
            self.assertEqual(metadata['analysis_status'],'no_regions')

    def test_twelve_regions_do_not_inherit_xgv_names(self):
        image=Image.new('RGB',(800,800),'white');draw=ImageDraw.Draw(image)
        for index in range(12):
            x=(index%4)*190+10;y=(index//4)*250+10
            draw.rectangle((x,y,x+140,y+180),fill='#db99a3')
        buffer=io.BytesIO();image.save(buffer,'PNG')
        parts,metadata=template_parts_from_layout(buffer.getvalue())
        self.assertEqual(len(parts),12)
        self.assertEqual(parts[0]['name'],'裁片 01')
        self.assertEqual(parts[0]['role'],'piece-01')

    def test_one_piece_is_a_valid_new_layout(self):
        image=Image.new('RGB',(500,600),'white');draw=ImageDraw.Draw(image)
        draw.polygon([(10,15),(400,15),(450,500),(100,560)],fill='#dc8999')
        buffer=io.BytesIO();image.save(buffer,'PNG')
        parts,metadata=template_parts_from_layout(buffer.getvalue())
        self.assertEqual(len(parts),1)
        self.assertEqual(parts[0]['source_box'],[10,15,451,561])

    def test_alpha_transparency_is_paper(self):
        image=Image.new('RGBA',(500,600),(0,0,0,0))
        ImageDraw.Draw(image).rectangle((20,50,400,500),fill='#d58c96')
        buffer=io.BytesIO();image.save(buffer,'PNG')
        regions,metadata=detect_layout_regions(buffer.getvalue())
        self.assertEqual(len(regions),1)
        self.assertEqual(regions[0][:4],(20,50,401,501))

    def test_generated_canvas_boxes_do_not_overlap(self):
        data,_=pink_sheet();parts,_=template_parts_from_layout(data)
        for i,a in enumerate(parts):
            for b in parts[i+1:]:
                self.assertTrue(a['x']+a['w']<=b['x'] or b['x']+b['w']<=a['x'] or a['y']+a['h']<=b['y'] or b['y']+b['h']<=a['y'])

if __name__=='__main__':unittest.main()
