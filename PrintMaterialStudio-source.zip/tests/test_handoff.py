import copy
import hashlib
from io import BytesIO
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

from PIL import Image, ImageDraw
from print_studio.app import DEFAULT_TEMPLATE, normalize_template
from print_studio.handoff import TaskError, inspect_result, prepare_task, task_zip


def picture(plain=False):
    image = Image.new('RGB', (64, 48), '#284a62')
    if not plain:
        draw = ImageDraw.Draw(image)
        draw.rectangle((5, 5, 30, 30), fill='#ccddee')
        draw.ellipse((33, 15, 50, 32), fill='#bcdef0')
    buffer = BytesIO(); image.save(buffer, format='PNG')
    return buffer.getvalue()


class HandoffTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.products = root / 'products'; self.products.mkdir()
        self.outputs = root / 'outputs'; self.outputs.mkdir()
        self.template = normalize_template(copy.deepcopy(DEFAULT_TEMPLATE))
        self.template['parts'][0]['extraction_note'] = '只处理已确认的领条范围，排除两侧门襟。'
        self.folder = self.products / 'product-a'; self.folder.mkdir()
        self.meta = {'template_id': self.template['id'], 'files': ['正面.png'], 'front': '正面.png'}
        (self.folder / 'meta.json').write_text(json.dumps(self.meta), encoding='utf-8')
        (self.folder / '正面.png').write_bytes(picture())
        self.payload = {'template_id': self.template['id'], 'part_id': '01', 'product_ids': ['product-a']}

    def prepare(self, payload=None):
        return prepare_task(payload or self.payload, [self.template], self.products, self.outputs)

    def test_task_keeps_original_product_bytes_and_source_identity(self):
        task = self.prepare()
        with zipfile.ZipFile(BytesIO(task_zip(task))) as archive:
            self.assertEqual(archive.read('products/product-a/正面.png'), picture())
            manifest = json.loads(archive.read('manifest.json'))
            source = manifest['products'][0]['images'][0]
            self.assertEqual(source['size_px'], [64, 48])
            self.assertEqual(source['sha256'], hashlib.sha256(picture()).hexdigest())
            self.assertEqual(manifest['part']['extraction_note'], self.template['parts'][0]['extraction_note'])
            self.assertEqual(manifest['products'][0]['source_regions'], [])
            self.assertFalse(any('layout' in name and name.endswith(('.png', '.jpg')) for name in archive.namelist()))

    def test_source_quads_travel_with_same_product_and_part(self):
        for name, product in [('material-a', 'product-a'), ('material-b', 'product-b')]:
            folder = self.outputs / name; folder.mkdir()
            record = {'template_id': self.template['id'], 'product_id': product, 'part_id': '01',
                      'status': 'approved', 'plan': {'quad': [1, 2, 30, 2, 30, 40, 1, 40]}}
            (folder / 'meta.json').write_text(json.dumps(record), encoding='utf-8')
        regions = self.prepare()['manifest']['products'][0]['source_regions']
        self.assertEqual(len(regions), 1)
        self.assertEqual(regions[0]['quad_px'], [1, 2, 30, 2, 30, 40, 1, 40])
        self.assertEqual(regions[0]['source_file'], 'products/product-a/正面.png')

    def test_missing_part_never_falls_back_to_right_front(self):
        with self.assertRaises(TaskError) as error:
            self.prepare({**self.payload, 'part_id': '99'})
        self.assertEqual(error.exception.status, 404)

    def test_unknown_template_does_not_use_default_template(self):
        with self.assertRaises(TaskError):
            self.prepare({**self.payload, 'template_id': 'missing'})

    def test_other_template_product_is_not_exported(self):
        (self.folder / 'meta.json').write_text(json.dumps({**self.meta, 'template_id': 'other'}))
        with self.assertRaises(TaskError) as error:
            self.prepare()
        self.assertEqual(error.exception.status, 409)

    def test_missing_image_cannot_silently_produce_partial_task(self):
        (self.folder / '正面.png').unlink()
        with self.assertRaises(TaskError):
            self.prepare()

    def test_mirror_requires_a_real_source_part(self):
        with self.assertRaises(TaskError):
            self.prepare({**self.payload, 'mirror': True})

    def test_flat_occupancy_color_is_not_accepted_by_default(self):
        with self.assertRaises(TaskError) as error:
            inspect_result(picture(plain=True), [64, 48])
        self.assertEqual(error.exception.status, 422)

    def test_genuine_plain_requires_explicit_check_and_is_still_unreviewed(self):
        image, validation = inspect_result(picture(plain=True), [64, 48], plain_confirmed=True)
        self.assertEqual(image.getpixel((20, 20)), (40, 74, 98))
        self.assertTrue(validation['plain_source_confirmed'])
        self.assertEqual(validation['source_fidelity'], 'requires_human_review')

    def test_patterned_result_keeps_source_pixels_but_still_needs_review(self):
        image, validation = inspect_result(picture(), [64, 48])
        self.assertEqual(image.getpixel((10, 10)), (204, 221, 238))
        self.assertFalse(validation['nearly_plain'])
        self.assertEqual(validation['source_fidelity'], 'requires_human_review')

    def test_wrong_dimensions_are_rejected_without_stretching(self):
        with self.assertRaises(TaskError):
            inspect_result(picture(), [1536, 2048])


if __name__ == '__main__':
    unittest.main()
