import json
from io import BytesIO
import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageDraw
from print_studio.app import DEFAULT_TEMPLATE, PARTS, export_size, layout_svg, normalize_template, template_parts_from_layout, unique_template_names
from print_studio.provider import build_prompt
from print_studio.texture import extract_visible, extract_perspective, fill_mask_from_neighbors, rebuild_surface


class StudioRulesTest(unittest.TestCase):
    def test_confirmed_template_has_twelve_roles(self):
        self.assertEqual(len(PARTS), 12)
        self.assertEqual([p['name'] for p in PARTS], ['领子','左门襟','右门襟','左口袋','后片','左前片','右口袋','右前片','左袖','右袖','左袖口','右袖口'])


    def test_template_names_are_unique_case_insensitively(self):
        values, changed = unique_template_names([{"id":"a","name":"新模板"},{"id":"b","name":"新模板"},{"id":"c","name":"新模板 2"}])
        self.assertTrue(changed)
        names = [item["name"].casefold() for item in values]
        self.assertEqual(len(names), len(set(names)))

    def test_normalize_accepts_legacy_mirror_source(self):
        template = normalize_template({"id":"draft","name":"草稿","updated_at":"fixed","parts":[{"id":"01","name":"A","mirror_source":"02"}]})
        self.assertEqual(template["updated_at"], "fixed")
        self.assertEqual(template["parts"][0]["mirrorSource"], "02")

    def test_uploaded_layout_creates_editable_component_boxes(self):
        image = Image.new("RGB", (800, 600), "white")
        draw = ImageDraw.Draw(image)
        draw.rectangle((20, 20, 180, 150), fill="#25364b")
        draw.rectangle((230, 40, 400, 240), fill="#6d8ca8")
        draw.rectangle((80, 320, 300, 560), fill="#a36a55")
        buffer = BytesIO()
        image.save(buffer, format="PNG")
        parts, metadata = template_parts_from_layout(buffer.getvalue())
        self.assertEqual(metadata["detected_count"], 3)
        self.assertEqual([part["id"] for part in parts], ["01", "02", "03"])
        self.assertTrue(all(part["w"] > 0 and part["h"] > 0 for part in parts))

    def test_export_modes(self):
        self.assertEqual(export_size({'mode':'square'}), [1536,1536])
        self.assertEqual(export_size({'mode':'portrait'}), [1536,2048])
        self.assertEqual(export_size({'mode':'landscape'}), [2048,1536])
        self.assertEqual(export_size({'mode':'strip','source_w':579,'source_h':64})[1], 1536)

    def test_strip_expansion_and_svg_markers(self):
        svg=layout_svg(DEFAULT_TEMPLATE)
        self.assertEqual(svg.count("class='part"), 12)
        self.assertGreaterEqual(svg.count('stroke-dasharray'), 3)
        self.assertIn("data-id='08'", svg)

    def test_normalize_is_editable(self):
        template=normalize_template({'id':'draft','name':'草稿','confirmed':False,'parts':PARTS})
        self.assertFalse(template['confirmed'])
        self.assertTrue(all(p['name_editable'] and p['role_mapping_editable'] for p in template['parts']))
        self.assertEqual(template['parts'][5]['export_size_px'], [1536,2048])

    def test_pixel_lock_extraction_marks_only_missing_area(self):
        source=Image.new('RGB',(200,200),'#112233')
        for x in range(60,140):
            for y in range(30,170): source.putpixel((x,y),(210,40,70))
        material,mask,plan=extract_visible(source,(60,30,140,170),(1536,2048))
        self.assertEqual(material.size,(1536,2048))
        self.assertEqual(mask.getpixel((768,1024)),255)
        self.assertTrue(plan.preserves_visible_pixels)
        self.assertEqual(plan.generation_scope,'missing-area-only')

    def test_perspective_extract_preserves_source_palette(self):
        source=Image.new('RGB',(100,100),'#123456')
        for x in range(20,80):
            for y in range(20,80): source.putpixel((x,y),(200,30,40))
        material,mask=extract_perspective(source,(20,20,80,20,80,80,20,80),(60,60))
        self.assertEqual(material.getpixel((30,30)),(200,30,40))
        self.assertEqual(mask.getpixel((30,30)),255)

    def test_projective_surface_marks_occlusion_without_exporting_it(self):
        source = Image.new('RGB',(100,100),'white')
        ImageDraw.Draw(source).rectangle((20,20,80,80),fill=(20,120,40))
        material, mask, report = rebuild_surface(source,(20,20,80,20,80,80,20,80),(60,60),[(0.25,0.25,0.5,0.5)])
        self.assertEqual(material.size,(60,60))
        self.assertEqual(report['status'],'needs_completion')
        self.assertEqual(mask.getpixel((5,5)),255)
        self.assertEqual(mask.getpixel((20,20)),0)
        self.assertEqual(material.getpixel((20,20)),(244,215,225))

    def test_neighbor_fill_does_not_modify_visible_center(self):
        source=Image.new('RGB',(100,100),(20,30,40)); source.paste((210,50,60),(20,20,80,80))
        mask=Image.new('L',(100,100),0); mask.paste(255,(20,20,80,80))
        result=fill_mask_from_neighbors(source,mask)
        self.assertEqual(result.getpixel((50,50)),(210,50,60))

    def test_provider_prompt_forbids_global_redraw(self):
        prompt=build_prompt({'id':'08','name':'右前片'})
        self.assertIn('可见区域必须直接保留',prompt)
        self.assertIn('只能根据该部件可见区域四周',prompt)
        self.assertIn('禁止重新绘制',prompt)

    def test_preview_is_self_contained(self):
        html=Path('dist/preview.html').read_text(encoding='utf-8')
        self.assertIn('meta name="print-studio-runtime" content="preview"', html)
        self.assertNotIn('href="/static/style.css"', html)
        self.assertNotIn('src="/static/app.js"', html)
        self.assertNotIn('__STUDIO_', html)


if __name__ == '__main__':
    unittest.main()
