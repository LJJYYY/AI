#!/usr/bin/env python3
import argparse
from print_studio.app import serve

parser = argparse.ArgumentParser(description='启动本机裁片素材图提取工具')
parser.add_argument('--host', default='127.0.0.1')
parser.add_argument('--port', type=int, default=18765)
parser.add_argument('--no-browser', action='store_true', help='兼容旧启动脚本，不自动打开浏览器')
args = parser.parse_args()
serve(args.host, args.port)
