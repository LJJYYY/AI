const PREVIEW = document.querySelector('meta[name="print-studio-runtime"]')?.content !== 'server';
const STORE_KEY = 'print-material-studio-v4';
const LEGACY_STORE_KEYS = ['print-material-studio-v3'];
const MODE_LABELS = {strip:'长条原比例', square:'正方形 1:1', portrait:'竖向 3:4', landscape:'横向 4:3'};
const ROLE_LABELS = {
  collar:'领子', 'left-placket':'左门襟', 'right-placket':'右门襟',
  'left-pocket':'左口袋', back:'后片', 'left-front':'左前片',
  'right-pocket':'右口袋', 'right-front':'右前片', 'left-sleeve':'左袖',
  'right-sleeve':'右袖', 'left-cuff':'左袖口', 'right-cuff':'右袖口'
};
const seedParts = [
  ['01','领子','collar','strip',140,10,1018,113,579,64],
  ['02','左门襟','left-placket','strip',10,150,70,707,47,475],
  ['03','右门襟','right-placket','strip',100,150,70,709,47,476],
  ['04','左口袋','left-pocket','square',200,330,130,130,90,105],
  ['05','后片','back','square',360,150,440,440,338,375],
  ['06','左前片','left-front','portrait',830,150,330,440,145,371],
  ['07','右口袋','right-pocket','square',10,900,160,160,92,106],
  ['08','右前片','right-front','portrait',200,670,240,320,150,369],
  ['09','左袖','left-sleeve','square',470,670,300,300,222,241],
  ['10','右袖','right-sleeve','square',800,670,360,360,220,240],
  ['11','左袖口','left-cuff','landscape',720,1090,200,150,133,64],
  ['12','右袖口','right-cuff','landscape',960,1090,200,150,131,62],
].map(([id,name,role,mode,x,y,w,h,source_w,source_h]) => ({id,name,role,mode,x,y,w,h,source_w,source_h,mirror:false,mirrorSource:'',keepTexture:false}));
const state = {
  templates: [], template: null, selected: '01', templateDirty: false, activeTemplateId: null,
  draftTemplates: [], products: [], productTemplateId: null, jobs: [], samples: null,
  api: {configured:false, model:'gpt-image-2.5'}, cleanSample:false, texture:false, mirror:false,
  dragging:null, layoutFile:null, layoutPreviewUrl:null, savePromise:null, material:null
};
const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const clone = value => JSON.parse(JSON.stringify(value));
const now = () => new Date().toISOString();

function toast(message){
  const el = $('#toast');
  if (!el) return;
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 2800);
}
function escapeHtml(value){return String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));}
function roleLabel(part){return ROLE_LABELS[part?.role] || part?.name || part?.role || '自定义部件';}
function partLabel(part){return `${part?.id || '--'} · ${part?.name || roleLabel(part)}`;}
function positiveInt(value, fallback=1){const parsed=Number(value);return Number.isFinite(parsed) ? Math.max(1,Math.round(parsed)) : fallback;}
function nonnegativeInt(value, fallback=0){const parsed=Number(value);return Number.isFinite(parsed) ? Math.max(0,Math.round(parsed)) : fallback;}
function normalizePart(part={}, index=0){
  const result = clone(part);
  result.id = String(result.id || String(index + 1).padStart(2,'0'));
  result.name = String(result.name || roleLabel(result) || `裁片 ${result.id}`).trim();
  result.role = String(result.role || `piece-${result.id}`).trim();
  result.mode = ['strip','square','portrait','landscape'].includes(result.mode) ? result.mode : 'portrait';
  result.x = nonnegativeInt(result.x, 0); result.y = nonnegativeInt(result.y, 0);
  result.w = positiveInt(result.w, 80); result.h = positiveInt(result.h, 80);
  result.source_w = positiveInt(result.source_w, result.w); result.source_h = positiveInt(result.source_h, result.h);
  result.mirror = Boolean(result.mirror);
  result.mirrorSource = String(result.mirrorSource ?? result.mirror_source ?? '');
  delete result.mirror_source;
  result.keepTexture = Boolean(result.keepTexture ?? result.keep_texture);
  delete result.keep_texture;
  result.export_size_px = exportSize(result);
  return result;
}
function normalizeClientTemplate(template={}){
  const result = clone(template);
  result.id = String(result.id || `draft-${Date.now()}`);
  result.name = String(result.name || '未命名模板').trim() || '未命名模板';
  result.confirmed = Boolean(result.confirmed);
  result.created_at = result.created_at || now();
  result.updated_at = result.updated_at || result.created_at;
  result.parts = (result.parts?.length ? result.parts : seedParts).map(normalizePart);
  return result;
}
function makeTemplate(partList=seedParts, name='12块针织上衣模板', confirmed=true, id='confirmed-12-part'){
  return normalizeClientTemplate({id,name,confirmed,parts:clone(partList),left_right:'wearer-anatomical',created_at:now(),updated_at:now()});
}
function exportSize(part){
  if (part.mode==='square') return [1536,1536];
  if (part.mode==='landscape') return [2048,1536];
  if (part.mode==='portrait') return [1536,2048];
  const sw=positiveInt(part.source_w||part.w), sh=positiveInt(part.source_h||part.h);
  return sw>=sh ? [Math.round(1536*sw/sh),1536] : [1536,Math.round(1536*sh/sw)];
}

function persist(){
  try {
    const drafts = state.templates.filter(t => t.isDraft || t.dirty).map(clone);
    if (state.template && (state.templateDirty || state.template.isDraft || state.template.dirty) && !drafts.some(t => t.id===state.template.id)) drafts.push(clone(state.template));
    localStorage.setItem(STORE_KEY, JSON.stringify({
      activeTemplateId: state.template?.id || state.activeTemplateId,
      draftTemplates: drafts,
      products: state.products,
      texture: state.texture,
      mirror: state.mirror,
      productTemplateId: state.productTemplateId
    }));
  } catch (error) { /* local storage is optional */ }
}
function restore(){
  let saved = null;
  for (const key of [STORE_KEY, ...LEGACY_STORE_KEYS]) {
    try { saved = JSON.parse(localStorage.getItem(key) || 'null'); } catch (error) { saved = null; }
    if (saved) break;
  }
  if (!saved) return;
  state.activeTemplateId = saved.activeTemplateId || saved.template?.id || null;
  state.draftTemplates = Array.isArray(saved.draftTemplates) ? saved.draftTemplates.map(normalizeClientTemplate) : [];
  if (saved.draftTemplate) state.draftTemplates.push(normalizeClientTemplate(saved.draftTemplate));
  state.draftTemplates = [...new Map(state.draftTemplates.map(item => [item.id, item])).values()];
  // v3 stored a full template but did not record whether it was dirty. Only restore
  // old drafts; saved templates are reloaded from the server as the source of truth.
  if (saved.template?.isDraft || String(saved.template?.id || '').startsWith('draft-')) {
    const legacyDraft = normalizeClientTemplate(saved.template);
    state.draftTemplates = [...state.draftTemplates.filter(item => item.id !== legacyDraft.id), legacyDraft];
  }
  if (Array.isArray(saved.products)) state.products = saved.products;
  state.productTemplateId = saved.productTemplateId || null;
  if (typeof saved.texture === 'boolean') state.texture = saved.texture;
  if (typeof saved.mirror === 'boolean') state.mirror = saved.mirror;
}

async function api(path, options={}){
  if (PREVIEW) return previewApi(path, options);
  const response = await fetch(path, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.message || data.error || `HTTP ${response.status}`), {data,status:response.status});
  return data;
}
function previewApi(path, options={}){
  const method = (options.method || 'GET').toUpperCase();
  if (path === '/api/status') return Promise.resolve({configured:false,model:'gpt-image-2.5',mode:'preview'});
  if (path === '/api/templates/analyze' && method === 'POST') {
    const file = options.body?.get?.('layout');
    const draft = makeTemplate(seedParts, '新上传布局草稿', false, `draft-${Date.now()}`);
    draft.isDraft = true; draft.dirty = true;
    draft.layout_source = {filename:file?.name || '布局图片', width:0, height:0, detected_count:0, analysis_method:'preview-manual'};
    return Promise.resolve({template:draft,message:'预览模式已载入布局图；请在空白布局中手动核对部件'});
  }
  if (path === '/api/templates' && method === 'POST') {
    const body = normalizeClientTemplate(JSON.parse(options.body || '{}'));
    const duplicate = state.templates.find(item => item.id !== body.id && item.name.trim().toLocaleLowerCase() === body.name.trim().toLocaleLowerCase());
    if (duplicate) return Promise.reject(Object.assign(new Error(`模板名称已存在：${body.name}`), {status:409}));
    body.isDraft = false; body.dirty = false;
    state.templates = [...state.templates.filter(item => item.id !== body.id), body];
    return Promise.resolve(clone(body));
  }
  if (path.startsWith('/api/templates/') && method === 'DELETE') {
    const id = decodeURIComponent(path.split('/')[3] || '');
    state.templates = state.templates.filter(item => item.id !== id);
    return Promise.resolve({id,deleted:true});
  }
  if (path === '/api/products' && method === 'POST') {
    const item = {id:`product-${Date.now()}-${Math.random().toString(16).slice(2)}`,name:'离线商品',files:['商品效果图'],front:'商品效果图',back:null};
    state.products.push(item); return Promise.resolve(item);
  }
  if (path === '/api/jobs' && method === 'POST') return Promise.reject(Object.assign(new Error('预览模式不会调用生成服务，请启动本机服务'),{status:409}));
  if (path === '/api/templates') return Promise.resolve(clone(state.templates.length ? state.templates : [state.template || makeTemplate()]));
  if (path === '/api/products') return Promise.resolve(state.products);
  if (path === '/api/jobs') return Promise.resolve(state.jobs);
  if (path === '/api/samples') return Promise.resolve({available:true,status:'离线预览 · 当前模板结构占位',parts:(state.template?.parts || seedParts).map(p=>({filename:`${p.id}-${p.role}.jpg`,available:false,size_px:exportSize(p)}))});
  return Promise.resolve({});
}

function dedupeTemplateNames(values){
  const seen = new Set();
  return values.map((item,index) => {
    const next = normalizeClientTemplate(item);
    const base = next.name || `未命名模板 ${index + 1}`;
    let name = base; let suffix = 2;
    while (seen.has(name.toLocaleLowerCase())) name = `${base} ${suffix++}`;
    next.name = name; seen.add(name.toLocaleLowerCase());
    return next;
  });
}
function nextTemplateName(){
  const used = new Set(state.templates.map(t => (t.name || '').trim().toLocaleLowerCase()));
  let index = 1; let name = '新模板';
  while (used.has(name.toLocaleLowerCase())) name = `新模板 ${++index}`;
  return name;
}
function templateNameConflict(name, id){
  const normalized = name.trim().toLocaleLowerCase();
  return state.templates.find(item => item.id !== id && (item.name || '').trim().toLocaleLowerCase() === normalized);
}
function renderTemplateSelect(){
  const select = $('#template-select');
  if (!select) return;
  select.innerHTML = state.templates.map(template => `<option value="${escapeHtml(template.id)}" ${template.id===state.template?.id?'selected':''}>${escapeHtml(template.name)}${template.isDraft || template.dirty ? ' · 未保存' : ''}</option>`).join('');
  if (state.template) select.value = state.template.id;
  if ($('#product-template-select')) renderProductTemplateSelect();
}
function syncCurrentTemplate(){
  if (!state.template) return;
  const copy = clone(state.template);
  const index = state.templates.findIndex(item => item.id === copy.id);
  if (index >= 0) state.templates[index] = copy; else state.templates.push(copy);
}
function setTemplateDirty(message='修改待保存'){
  if (!state.template) return;
  state.templateDirty = true;
  state.template.dirty = true;
  syncCurrentTemplate();
  renderTemplateSelect();
  persist();
  markSaved(message);
}
function replaceTemplate(saved){
  const next = normalizeClientTemplate(saved);
  next.isDraft = false; next.dirty = false;
  state.templates = [...state.templates.filter(item => item.id !== next.id), next];
  state.template = clone(next);
  state.activeTemplateId = next.id;
  state.templateDirty = false;
  state.draftTemplates = state.draftTemplates.filter(item => item.id !== next.id);
  renderTemplateSelect(); renderLayout(); renderPartList(); renderTemplateSource(); persist();
}
async function saveCurrentTemplate(successMessage='模板已保存'){
  if (!state.template) return false;
  const input = $('#template-name');
  const name = (input?.value || state.template.name || '').trim();
  if (!name) { toast('模板名称不能为空'); input?.focus(); return false; }
  const duplicate = templateNameConflict(name, state.template.id);
  if (duplicate) { toast(`模板名称已存在：${duplicate.name}`); input?.focus(); return false; }
  if (state.savePromise) return state.savePromise;
  state.template.name = name;
  syncCurrentTemplate();
  const payload = clone(state.template);
  delete payload.isDraft; delete payload.dirty;
  state.savePromise = api('/api/templates', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
    .then(saved => { replaceTemplate(saved); markSaved(successMessage); toast(successMessage); return true; })
    .catch(error => { toast(error.message || '模板保存失败'); return false; })
    .finally(() => { state.savePromise = null; });
  return state.savePromise;
}
async function saveTemplateName(){return saveCurrentTemplate('模板名称已保存');}

function modeColor(mode){return {strip:['#f5ead5','#b8843b'],square:['#e3f0e9','#4d8771'],portrait:['#e6eef9','#5475a9'],landscape:['#eee8fa','#8064ab']}[mode] || ['#e6eef9','#5475a9'];}
function layoutSvgMarkup(template, clean=false){
  const svg = [`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1300"><rect width="1200" height="1300" fill="#fbfbf7"/>`];
  for (const part of template.parts || []) {
    const [fill,stroke] = modeColor(part.mode);
    svg.push(`<rect class="part" data-id="${escapeHtml(part.id)}" x="${part.x}" y="${part.y}" width="${part.w}" height="${part.h}" rx="12" fill="${fill}" stroke="${stroke}" stroke-width="3"/>`);
    if (part.mode === 'strip') svg.push(`<rect x="${part.x+part.w/12}" y="${part.y+part.h/12}" width="${part.w*5/6}" height="${part.h*5/6}" fill="none" stroke="${stroke}" stroke-dasharray="8 7" stroke-width="2"/>`);
    if (!clean) svg.push(`<text x="${part.x+part.w/2}" y="${part.y+part.h/2}" text-anchor="middle" dominant-baseline="middle" font-family="Arial,sans-serif" font-size="${Math.max(14,Math.min(30,part.w/8))}" font-weight="700" fill="#25334a">${escapeHtml(part.id)}</text>`);
  }
  svg.push('</svg>'); return svg.join('');
}
function renderTemplateSource(){
  const card = $('#layout-source-card'); const image = $('#layout-source-preview');
  if (!card || !image) return;
  const source = state.template?.layout_source;
  const hasSource = Boolean(source || state.layoutPreviewUrl);
  card.hidden = !hasSource;
  if (!hasSource) return;
  const filename = source?.filename || state.layoutFile?.name || '布局图片';
  const dimensions = source?.width && source?.height ? `${source.width} × ${source.height}` : '尺寸待读取';
  const detected = source?.detected_count ? `检测到 ${source.detected_count} 块` : '请手动核对边界';
  $('#layout-source-name').textContent = filename;
  $('#layout-source-meta').textContent = `${dimensions} · ${detected}`;
  const fallbackUrl = !state.template?.isDraft && state.template?.id ? `/api/templates/${encodeURIComponent(state.template.id)}/source` : '';
  const nextUrl = state.layoutPreviewUrl || source?.url || fallbackUrl;
  if (nextUrl && image.src !== new URL(nextUrl, window.location.href).href) image.src = nextUrl;
}
function renderLayout(){
  const template = state.template || makeTemplate();
  const nameInput = $('#template-name');
  if (nameInput && document.activeElement !== nameInput) nameInput.value = template.name || '';
  const svg = $('#layout-svg'); if (!svg) return;
  svg.innerHTML = '';
  for (const part of template.parts || []) {
    const [fill,stroke] = modeColor(part.mode);
    const rect = document.createElementNS('http://www.w3.org/2000/svg','rect');
    Object.entries({class:`part ${part.id===state.selected?'selected':''}`,'data-id':part.id,x:part.x,y:part.y,width:part.w,height:part.h,rx:12,fill,stroke,'stroke-width':3}).forEach(([key,value])=>rect.setAttribute(key,value));
    rect.addEventListener('pointerdown', startPartDrag); rect.addEventListener('click', () => focusPart(part.id)); svg.appendChild(rect);
    if (part.mode === 'strip') {
      const inner = document.createElementNS('http://www.w3.org/2000/svg','rect');
      Object.entries({x:part.x+part.w/12,y:part.y+part.h/12,width:part.w*5/6,height:part.h*5/6,fill:'none',stroke,'stroke-dasharray':'8 7','stroke-width':2,'pointer-events':'none'}).forEach(([key,value])=>inner.setAttribute(key,value)); svg.appendChild(inner);
    }
    const text = document.createElementNS('http://www.w3.org/2000/svg','text'); text.textContent = part.id;
    Object.entries({x:part.x+part.w/2,y:part.y+part.h/2,'text-anchor':'middle','dominant-baseline':'middle',fill:'#25334a','font-size':Math.max(14,Math.min(30,part.w/8)),'font-family':'Arial,sans-serif','font-weight':700,'pointer-events':'none'}).forEach(([key,value])=>text.setAttribute(key,value)); svg.appendChild(text);
  }
  $('#part-count').textContent = `${template.parts.length} 块`;
  $('#part-count-mini').textContent = `${template.parts.length} / ${template.parts.length}`;
  $('#template-status').textContent = state.templateDirty ? '编辑中 · 待保存' : (template.confirmed ? '布局已确认' : '待核对确认');
  $('#template-status').className = `pill ${state.templateDirty || !template.confirmed ? 'warning' : ''}`;
  $('#confirm-title').textContent = template.confirmed && !state.templateDirty ? '布局已确认' : '等待确认布局';
  $('#confirm-copy').textContent = state.templateDirty ? '当前有未保存修改，保存后才能用于生成。' : (template.confirmed ? '当前模板可用于选择商品和生成素材。' : '请确认数量、位置、比例和部件名称后再生成。');
  $('#confirm-template').textContent = template.confirmed && !state.templateDirty ? '重新确认布局' : '确认并保存布局';
  renderTemplateSource();
}
function scrollToPart(id){
  cancelAnimationFrame(scrollToPart.frame);
  scrollToPart.frame = requestAnimationFrame(() => {
    const root = $('#part-list');
    const item = root ? [...root.children].find(node => node.dataset.id === id) : null;
    if (!root || !item) return;
    const rr=root.getBoundingClientRect(), ir=item.getBoundingClientRect();
    root.scrollTop += ir.top - rr.top - root.clientTop - 12;
    // Also bring the inspector into the page viewport; nested scrolling alone
    // cannot reveal an inspector sitting above/below the browser viewport.
    const after=item.getBoundingClientRect();
    if(after.top<12 || after.bottom>innerHeight-12) item.scrollIntoView({block:'center',behavior:'instant'});
    item.classList.add('focus-flash');
  });
}
function focusPart(id){
  if (!state.template?.parts.some(part => part.id===id)) return;
  state.selected = id; renderLayout(); renderPartList(); scrollToPart(id,'auto');
}
function startPartDrag(event){
  if (event.button !== 0) return;
  const part = state.template?.parts.find(p => p.id === event.currentTarget.dataset.id); if (!part) return;
  state.selected = part.id;
  $$('#layout-svg .part').forEach(node => node.classList.toggle('selected', node.dataset.id === part.id));
  renderPartList(); scrollToPart(part.id, 'auto');
  const svg = $('#layout-svg');
  state.dragging = {part,node:event.currentTarget,svg,startX:event.clientX,startY:event.clientY,originX:part.x,originY:part.y,moved:false};
  event.currentTarget.setPointerCapture?.(event.pointerId);
  event.currentTarget.addEventListener('pointermove', dragPart);
  event.currentTarget.addEventListener('pointerup', endPartDrag, {once:true});
  event.stopPropagation();
}
function dragPart(event){
  const drag = state.dragging; if (!drag) return;
  const rect = drag.svg.getBoundingClientRect();
  const scaleX = rect.width / 1200, scaleY = rect.height / 1300;
  const dx = (event.clientX-drag.startX)/scaleX;
  const dy = (event.clientY-drag.startY)/scaleY;
  if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) return;
  drag.moved = true;
  drag.part.x = Math.max(0, Math.min(1200 - drag.part.w, drag.originX + dx));
  drag.part.y = Math.max(0, Math.min(1300 - drag.part.h, drag.originY + dy));
  drag.node.setAttribute('x', drag.part.x); drag.node.setAttribute('y', drag.part.y);
  state.template.confirmed = false; state.templateDirty = true; state.template.dirty = true;
}
function endPartDrag(){
  if (!state.dragging) return;
  const moved = state.dragging.moved;
  state.dragging = null;
  if (moved) setTemplateDirty('布局修改待保存');
  if(moved) {renderLayout(); renderPartList();}
  focusPart(state.selected);
}
function renderPartList(){
  const root = $('#part-list'); if (!root || !state.template) return;
  const parts = state.template.parts || [];
  root.innerHTML = parts.map(part => {
    const size = exportSize(part); const sourceId = part.mirrorSource || '';
    const sourceExists = parts.some(other => other.id === sourceId && other.id !== part.id);
    const sourceOptions = parts.filter(other => other.id !== part.id).map(other => `<option value="${escapeHtml(other.id)}" ${other.id===sourceId?'selected':''}>${escapeHtml(partLabel(other))}</option>`).join('');
    const missingOption = sourceId && !sourceExists ? `<option value="${escapeHtml(sourceId)}" selected disabled>已不存在：${escapeHtml(sourceId)}</option>` : '';
    return `<article class="part-item ${part.id===state.selected?'selected':''}" data-id="${escapeHtml(part.id)}">
      <div class="part-row"><span class="part-number">${escapeHtml(part.id)}</span><strong>${escapeHtml(part.name || roleLabel(part))}</strong><span class="part-mode">${escapeHtml(MODE_LABELS[part.mode] || part.mode)}</span></div>
      <div class="part-role">${escapeHtml(part.role || '自定义部件')}</div>
      <div class="part-geometry"><label>X<input class="geometry-x" type="number" min="0" value="${part.x}"></label><label>Y<input class="geometry-y" type="number" min="0" value="${part.y}"></label><label>宽<input class="geometry-w" type="number" min="24" value="${part.w}"></label><label>高<input class="geometry-h" type="number" min="24" value="${part.h}"></label></div>
      <input class="name" aria-label="${escapeHtml(part.id)}名称" value="${escapeHtml(part.name)}">
      <div class="part-meta"><label>比例<select class="mode"><option value="strip" ${part.mode==='strip'?'selected':''}>长条原比例</option><option value="portrait" ${part.mode==='portrait'?'selected':''}>竖向3:4</option><option value="landscape" ${part.mode==='landscape'?'selected':''}>横向4:3</option><option value="square" ${part.mode==='square'?'selected':''}>正方形1:1</option></select></label><label>导出尺寸<span class="size-readout">${size[0]} × ${size[1]}</span></label></div>
      <div class="part-options"><label><input type="checkbox" class="mirror" ${part.mirror?'checked':''}>镜像来源</label><select class="mirror-source" aria-label="${escapeHtml(part.id)}镜像来源"><option value="">不使用来源部件</option>${missingOption}${sourceOptions}</select><label><input type="checkbox" class="texture" ${part.keepTexture?'checked':''}>保留纹理</label></div>
    </article>`;
  }).join('');
  $$('.part-item', root).forEach(item => {
    item.addEventListener('click', event => { if (!event.target.closest('input,select,label,button')) focusPart(item.dataset.id); });
    item.querySelector('.name').addEventListener('change', event => updatePart(item.dataset.id,{name:event.target.value.trim() || `裁片 ${item.dataset.id}`}));
    ['x','y','w','h'].forEach(key=>item.querySelector(`.geometry-${key}`).addEventListener('change',event=>updatePart(item.dataset.id,{[key]:Number(event.target.value)})));
    item.querySelector('.mode').addEventListener('change', event => updatePart(item.dataset.id,{mode:event.target.value}));
    item.querySelector('.mirror').addEventListener('change', event => updatePart(item.dataset.id,{mirror:event.target.checked}));
    item.querySelector('.mirror-source').addEventListener('change', event => updatePart(item.dataset.id,{mirrorSource:event.target.value,mirror:Boolean(event.target.value)}));
    item.querySelector('.texture').addEventListener('change', event => updatePart(item.dataset.id,{keepTexture:event.target.checked}));
  });
}
function updatePart(id, patch){
  const part = state.template?.parts.find(p => p.id===id); if (!part) return;
  Object.assign(part, normalizePart({...part,...patch})); state.template.confirmed = false; state.selected = id; setTemplateDirty('部件修改待保存'); renderLayout(); renderPartList();
}

async function loadTemplates(){
  restore();
  let remote = [];
  try { remote = dedupeTemplateNames(await api('/api/templates')); } catch (error) { remote = []; }
  const drafts = [...state.draftTemplates].map(normalizeClientTemplate);
  let merged = remote.map(normalizeClientTemplate);
  for (const draft of drafts) {
    const index = merged.findIndex(item => item.id===draft.id);
    if (index >= 0) { if (draft.dirty || draft.isDraft) merged[index] = draft; }
    else merged.push(draft);
  }
  state.templates = dedupeTemplateNames(merged);
  if (!state.templates.length) state.templates = [makeTemplate()];
  const targetId = state.activeTemplateId;
  const target = state.templates.find(item => item.id===targetId) || state.templates[0] || makeTemplate();
  state.template = clone(target); state.activeTemplateId = target.id; state.templateDirty = Boolean(target.isDraft || target.dirty);
  state.draftTemplates = state.templates.filter(item => item.isDraft || item.dirty).map(clone);
  renderTemplateSelect(); renderProductTemplateSelect(); renderLayout(); renderPartList();
}
function selectTemplate(id){
  const found = state.templates.find(item => item.id===id); if (!found) return;
  if (state.template?.id===id) return;
  if (state.templateDirty && !window.confirm('当前模板有未保存修改，切换后会保留为草稿。是否继续？')) { renderTemplateSelect(); return; }
  syncCurrentTemplate();
  state.template = clone(found); state.activeTemplateId = found.id; state.templateDirty = Boolean(found.isDraft || found.dirty); state.selected = state.template.parts[0]?.id || '01';
  state.layoutFile = null; if (state.layoutPreviewUrl?.startsWith('blob:')) URL.revokeObjectURL(state.layoutPreviewUrl); state.layoutPreviewUrl = null;
  renderTemplateSelect(); renderLayout(); renderPartList(); renderTemplateSource(); persist();
}
function createTemplate(){
  if (state.templateDirty && !window.confirm('当前模板有未保存修改，继续新建会保留当前草稿。是否继续？')) return;
  syncCurrentTemplate();
  const template = makeTemplate(seedParts, nextTemplateName(), false, `draft-${Date.now()}-${Math.random().toString(16).slice(2,8)}`);
  template.isDraft = true; template.dirty = true;
  state.templates.push(template); state.template = clone(template); state.activeTemplateId = template.id; state.templateDirty = true; state.selected = '01';
  state.layoutFile = null; if (state.layoutPreviewUrl?.startsWith('blob:')) URL.revokeObjectURL(state.layoutPreviewUrl); state.layoutPreviewUrl = null;
  renderTemplateSelect(); renderLayout(); renderPartList(); persist(); toast('已创建新模板草稿，请核对后保存');
}
async function deleteCurrentTemplate(){
  if(!state.template) return;
  if(!window.confirm(`确定删除模板“${state.template.name}”吗？此操作不可恢复。`)) return;
  const id=state.template.id;
  try{
    if(!state.template.isDraft) await api(`/api/templates/${encodeURIComponent(id)}`,{method:'DELETE'});
    state.templates=state.templates.filter(item=>item.id!==id); state.draftTemplates=state.draftTemplates.filter(item=>item.id!==id);
    const next=state.templates[0]||makeTemplate(); state.template=clone(next); state.activeTemplateId=next.id; state.templateDirty=Boolean(next.isDraft||next.dirty); state.selected=next.parts[0]?.id||'01';
    renderTemplateSelect();renderLayout();renderPartList();persist();toast('模板已删除');
  }catch(error){toast(error.message||'模板删除失败');}
}
function renderProductTemplateSelect(){
  const select=$('#product-template-select'); if(!select)return;
  select.innerHTML=state.templates.map(t=>`<option value="${escapeHtml(t.id)}">${escapeHtml(t.name)}${t.isDraft||t.dirty?' · 未保存':''}</option>`).join('');
  state.productTemplateId=state.productTemplateId&&state.templates.some(t=>t.id===state.productTemplateId)?state.productTemplateId:(state.template?.id||state.templates[0]?.id||'');
  select.value=state.productTemplateId;
}
function selectedProductTemplate(){return state.templates.find(t=>t.id===state.productTemplateId)||state.template;}

function resetCurrentTemplate(){
  if (!state.template) return;
  state.template.parts = clone(seedParts).map(normalizePart); state.template.confirmed = false; state.selected = '01'; setTemplateDirty('已重置，等待保存'); renderLayout(); renderPartList(); toast('已重置当前模板布局，其他模板未改变');
}
async function analyzeLayoutFile(file){
  if (!file) return;
  if (state.templateDirty && !window.confirm('当前模板有未保存修改，上传新布局会创建新的草稿并保留当前草稿。是否继续？')) return;
  const form = new FormData(); form.append('layout', file, file.name); if (state.template?.isDraft) form.append('template_id', state.template.id);
  try {
    const result = await api('/api/templates/analyze',{method:'POST',body:form});
    let draft = normalizeClientTemplate(result.template); draft.isDraft = true; draft.dirty = true;
    state.templates = dedupeTemplateNames([...state.templates.filter(item => item.id!==draft.id), draft]);
    draft = state.templates.find(item => item.id===draft.id) || draft;
    state.template = clone(draft); state.activeTemplateId = draft.id; state.templateDirty = true; state.selected = draft.parts[0]?.id || '01'; state.layoutFile = file;
    if (state.layoutPreviewUrl?.startsWith('blob:')) URL.revokeObjectURL(state.layoutPreviewUrl);
    state.layoutPreviewUrl = URL.createObjectURL(file);
    renderTemplateSelect(); renderLayout(); renderPartList(); renderTemplateSource(); persist();
    toast(result.message || '已生成新布局草稿');
  } catch (error) { toast(error.message || '布局图片分析失败'); }
}
function clearLayoutSource(){
  if (!state.template) return;
  state.template.layout_source = null; state.layoutFile = null;
  if (state.layoutPreviewUrl?.startsWith('blob:')) URL.revokeObjectURL(state.layoutPreviewUrl);
  state.layoutPreviewUrl = null; setTemplateDirty('布局预览已清除'); renderTemplateSource();
}

async function loadStatus(){
  try {
    state.api = await api('/api/status');
    const badge=$('#model-state'); badge.textContent=state.api.configured?'已配置，可生成':'未配置 API 密钥'; badge.className=`pill ${state.api.configured?'':'warning'}`;
    if ($('#model')) $('#model').value = state.api.model || 'gpt-image-2.5';
    if ($('#daily-calls')) $('#daily-calls').value = state.api.daily_calls ?? 40;
    if ($('#daily-budget')) $('#daily-budget').value = state.api.daily_budget ?? 20;
    if ($('#api-key')) $('#api-key').placeholder = state.api.configured ? '已配置，留空表示保持不变' : '输入本机 API 密钥';
  } catch (error) { $('#model-state').textContent='预览模式'; $('#model-state').className='pill warning'; }
  if (PREVIEW) { $('#runtime-banner').hidden=false; $('#runtime-banner').textContent='当前为独立预览：模板编辑、编号布局和导出可用；真实识别与生成需要启动本机服务。'; $('#api-key').disabled=true; $('#save-settings').disabled=true; }
}
async function loadProducts(){try{state.products=await api('/api/products');}catch(error){}renderProducts();}
function renderSurfaceProductSelect(){const select=$('#surface-product-select');if(!select)return;select.innerHTML=state.products.map(p=>`<option value="${escapeHtml(p.id)}">${escapeHtml(p.name||p.id)}</option>`).join('');}
function parseSurfaceList(value){return String(value||'').split(';').map(chunk=>chunk.trim()).filter(Boolean).map(chunk=>chunk.split(',').map(Number)).filter(values=>values.length===4&&values.every(Number.isFinite));}
async function prepareSurface(){const productId=$('#surface-product-select')?.value;const template=selectedProductTemplate()||state.template;const partId=$('#surface-part-id').value.trim();const quad=($('#surface-quad').value||'').split(',').map(Number);if(!productId||!template||quad.length!==8||quad.some(value=>!Number.isFinite(value))){toast('请先选择商品并填写四点坐标');return;}try{const response=await api('/api/materials/prepare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({product_id:productId,template_id:template.id,part_id:partId,quad,exclusions:parseSurfaceList($('#surface-exclusions').value)})});state.material=response;$('#surface-status').textContent=`草稿已生成：${response.size_px.join(' × ')}，${response.unresolved_pixels?'仍有遮挡待补全':'可以审核'}`;$('#approve-surface').disabled=Boolean(response.unresolved_pixels);const preview=$('#surface-preview');preview.hidden=false;preview.src=`/api/materials/${response.id}/preview?${Date.now()}`;toast('部件校正草稿已生成');}catch(error){toast(error.message||'部件校正失败');}}
async function approveSurface(){if(!state.material)return;try{const result=await api(`/api/materials/${state.material.id}/approve`,{method:'POST'});state.material=result;$('#surface-status').textContent='已审核，可下载正式 JPG';$('#approve-surface').disabled=true;const link=document.createElement('a');link.href=`/api/materials/${result.id}/download`;link.download=`${result.part_id}-material.jpg`;link.click();toast('已导出正式 JPG');}catch(error){toast(error.message||'审核失败');}}
function renderProducts(){
  const root=$('#product-list'); if (!root) return;
  renderSurfaceProductSelect();
  $('#product-count').textContent=`${state.products.length} 件`;
  if(!state.products.length){root.innerHTML='<div class="empty-state"><div>⌁</div><strong>还没有商品图片</strong><span>上传后会在这里显示分组和正反面</span></div>';return;}
  root.innerHTML=state.products.map((product,index)=>{const thumb=product.front&&!PREVIEW?`<img src="/api/products/${encodeURIComponent(product.id)}/${encodeURIComponent(product.front)}" alt="">`:'◉';return `<article class="product-card" data-id="${escapeHtml(product.id)}"><div class="product-thumb">${thumb}</div><div class="product-info"><strong>${escapeHtml(product.name||`商品 ${index+1}`)}</strong><span>${product.files?.length||1} 张图 · 模板 ${escapeHtml(state.templates.find(t=>t.id===product.template_id)?.name||product.template_name||'未绑定')} · 正面 ${escapeHtml(product.front||'已上传')}${product.back?' · 背面 '+escapeHtml(product.back):''}</span></div><button class="remove-product" data-id="${escapeHtml(product.id)}" title="移除">×</button></article>`;}).join('');
  $$('.remove-product',root).forEach(button=>button.addEventListener('click',()=>{state.products=state.products.filter(product=>product.id!==button.dataset.id);renderProducts();persist();toast('已移除商品');}));
}
async function uploadOne(file,groupName){const form=new FormData();form.append('photos',file,file.webkitRelativePath||file.name);form.append('group',groupName||file.name.replace(/\.[^.]+$/,''));form.append('template_id',state.productTemplateId||state.template?.id||'');return api('/api/products',{method:'POST',body:form});}
async function uploadProducts(files){
  files=files.filter(file=>file.type.startsWith('image/')||/\.(jpe?g|png|webp)$/i.test(file.name)); if(!files.length){toast('没有可用的图片文件');return;}
  const folderMode=$('#folder-mode')?.checked;
  try {
    const items=[];
    if(folderMode){
      const groups=new Map(); files.forEach(file=>{const path=file.webkitRelativePath||file.name;const parts=path.split(/[\\/]/);const group=parts.length>1?parts[parts.length-2]:file.name.replace(/\.[^.]+$/,'');if(!groups.has(group))groups.set(group,[]);groups.get(group).push(file);});
      for(const [group,groupFiles] of groups){const form=new FormData();groupFiles.forEach(file=>form.append('photos',file,file.webkitRelativePath||file.name));form.append('group',group);form.append('template_id',state.productTemplateId||state.template?.id||'');items.push(await api('/api/products',{method:'POST',body:form}));}
    } else { for(const file of files) items.push(await uploadOne(file)); }
    state.products.push(...items); renderProducts(); persist(); toast(`已加入 ${items.length} 个商品`);
  } catch(error) { if(PREVIEW){files.forEach(file=>state.products.push({id:`preview-${Date.now()}-${Math.random()}`,name:file.name,files:[file.name],front:file.name,back:null}));renderProducts();toast('预览模式已载入文件名');} else toast(error.message||'商品上传失败'); }
}

function chatGPTInstruction(template,part){return `你正在执行裁片素材提取任务。当前模板：${template.name}；部件编号：${part.id}；部件名称：${part.name}。

硬性规则：只使用商品效果图作为花纹来源；裁片布局图只用于数量、位置、方向和比例，不得把布局图花纹当作参考。对商品图中该部件的可见花纹、颜色、边界、大小和相对位置做像素保真提取并校正透视，禁止整件衣服重绘、重新设计、随机增加纹样或把窄条原图直接当成成品。被手、内搭、背景、褶皱或其他部件遮挡的区域，只能根据同一部件可见边界附近的连续花纹局部补全；不能从其他部位复制设计。输出干净的平面矩形 JPG，去除人物、手、内搭、背景、褶皱和光影；保留印花边缘自然斑驳。素色领子和门襟保持素色。先处理当前指定部件，完成后只返回该部件素材图和简短说明。`}
function openChatGPTTask(){const template=selectedProductTemplate()||state.template;const part=template?.parts.find(p=>p.id===state.selected)||template?.parts[0];if(!template||!part){toast('请先选择模板和部件');return;}const prompt=chatGPTInstruction(template,part);const url=`https://chatgpt.com/?q=${encodeURIComponent(prompt)}`;const opened=window.open(url,'_blank','noopener,noreferrer');if(!opened){navigator.clipboard?.writeText(prompt);toast('浏览器阻止了新窗口，提示词已复制到剪贴板');}else toast('已打开 ChatGPT，并预填任务规则；请上传任务包中的商品图后发送');}

async function exportChatGPTTask(){
  if(!state.template?.confirmed||state.templateDirty){toast('请先保存并确认布局');showPanel('templates');return;}
  if(!state.products.length){toast('请先上传商品图');showPanel('products');return;}
  const activeTemplate=selectedProductTemplate()||state.template; const partId=state.selected||'08';
  try {
    if(PREVIEW){const manifest={template_id:activeTemplate.id,part_id:partId,products:state.products.map(p=>p.id),note:'请在 ChatGPT 网页中使用商品图，保留可见像素，仅局部补全'};download(`data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(manifest,null,2))}`,`chatgpt-task-${partId}.json`);toast('离线任务说明已导出');return;}
    const response=await fetch('/api/handoff/package',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({template_id:activeTemplate.id,part_id:partId,product_ids:state.products.map(p=>p.id),texture:state.texture,mirror:state.mirror})});
    if(!response.ok)throw new Error('任务包导出失败'); const blob=await response.blob(); const url=URL.createObjectURL(blob); const link=document.createElement('a');link.href=url;link.download=`chatgpt-task-${partId}.zip`;link.click();URL.revokeObjectURL(url);$('#handoff-status').textContent=`已导出 ${partId} 号任务包，请在 ChatGPT 网页生成后导回`;toast('ChatGPT 任务包已导出');
  } catch(error){toast(error.message||'任务包导出失败');}
}
async function importGeneratedResult(file){
  if(!file)return; const partId=state.selected||'08';
  try { if(PREVIEW){$('#handoff-status').textContent=`已载入 ${partId} 号结果（预览模式）`;toast('结果已载入预览');return;} const form=new FormData();form.append('part_id',partId);form.append('result',file,file.name);const response=await fetch('/api/handoff/import',{method:'POST',body:form});const result=await response.json();if(!response.ok)throw new Error(result.error||'结果导入失败');$('#handoff-status').textContent=`已导入 ${result.part_id} 号结果`;toast('ChatGPT 结果已导入本机');} catch(error){toast(error.message||'结果导入失败');}
}
async function startGeneration(){
  if(!state.template?.confirmed||state.templateDirty){toast('请先保存并确认布局，生成已阻止');showPanel('templates');return;}
  if(!state.products.length){toast('请先上传商品效果图');showPanel('products');return;}
  const activeTemplate=selectedProductTemplate()||state.template; if(!activeTemplate?.confirmed||activeTemplate.dirty){toast('所选商品模板尚未保存并确认');showPanel('templates');return;} try {const job=await api('/api/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({template_id:activeTemplate.id,product_ids:state.products.map(p=>p.id),output_mode:$('#output-mode').value,settings:{generationMode:$('#generation-mode').value,texture:state.texture,mirror:state.mirror,model:$('#model-select').value}})});state.jobs.unshift(job);toast('生成任务已加入队列');showPanel('jobs');renderJobs();}catch(error){toast(error.message||'生成未启动');if(error.status===409)openSettings();}
}
async function loadSamples(){try{state.samples=await api('/api/samples');}catch(error){state.samples={available:false,parts:state.template?.parts||seedParts};}renderSamples();}
function renderSamples(){
  const data=state.samples||{parts:state.template?.parts||seedParts}; $('#sample-status').textContent=data.available?'当前模板样品已加载':'等待样品生成 · 当前显示结构预览';
  const fallback=$('#sample-layout-fallback'); if(fallback){fallback.classList.toggle('clean',state.cleanSample);fallback.innerHTML=(state.template?.parts||seedParts).map(part=>`<div class="fallback-part" style="left:${part.x/1200*100}%;top:${part.y/1300*100}%;width:${part.w/1200*100}%;height:${part.h/1300*100}%">${escapeHtml(part.id)}</div>`).join('');}
  const root=$('#sample-parts'); if(!root)return;
  root.innerHTML=(data.parts||state.template?.parts||seedParts).map((part,index)=>{const p=state.template?.parts.find(x=>x.id===String(part.filename||'').slice(0,2))||state.template?.parts[index]||seedParts[index]||part;return `<article class="sample-card"><div class="sample-art"></div><div class="sample-card-body"><strong>${escapeHtml(partLabel(p))}</strong><span>${part.available?'已生成 JPG':'待生成'} · ${exportSize(p).join(' × ')}</span></div></article>`;}).join('');
}
async function loadJobs(){try{state.jobs=await api('/api/jobs');}catch(error){}renderJobs();}
function renderJobs(){
  const root=$('#job-list'); if(!root)return;
  if(!state.jobs.length){root.innerHTML='<div class="empty-state card"><div>◌</div><strong>暂无生成任务</strong><span>确认布局并上传商品图后，任务会出现在这里</span></div>';return;}
  root.innerHTML=state.jobs.map(job=>`<article class="job-card card"><div class="job-header"><strong>${escapeHtml(job.id)}</strong><span class="job-status ${escapeHtml(job.status)}">${job.status==='queued'?'排队中':job.status==='cancelled'?'已取消':job.status==='completed'?'已完成':'处理中'}</span></div><div class="job-meta"><span>${job.products?.length||0} 个商品</span><span>${job.parts?.length||0} 个裁片</span><span>${new Date(job.created_at||Date.now()).toLocaleString('zh-CN')}</span></div><div class="job-parts">${(job.parts||[]).map(part=>`<div class="job-part"><strong>${escapeHtml(part.id)}</strong><span>${part.status==='queued'?'排队':part.status==='done'?'完成':'待处理'}</span></div>`).join('')}</div><div class="job-actions">${job.status!=='cancelled'?`<button class="button secondary cancel-job" data-id="${escapeHtml(job.id)}">取消任务</button>`:''}</div></article>`).join('');
  $$('.cancel-job',root).forEach(button=>button.addEventListener('click',async()=>{try{const job=await api(`/api/jobs/${encodeURIComponent(button.dataset.id)}/cancel`,{method:'POST'});state.jobs=state.jobs.map(item=>item.id===job.id?job:item);renderJobs();toast('任务已取消');}catch(error){toast(error.message||'任务取消失败');}}));
}
function openSettings(){if(PREVIEW){toast('独立预览不会保存密钥，请启动本机服务');return;}$('#settings-dialog').classList.remove('hidden');}
function download(url,name){
  if(PREVIEW && url.startsWith('/api/download/template-preview')){const blob=new Blob([layoutSvgMarkup(state.template||makeTemplate(),false)],{type:'image/svg+xml'});const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download=name.replace(/\.jpg$/i,'.svg');link.click();return;}
  if(PREVIEW){toast('当前为预览模式，该下载需要启动本机服务');return;}
  const link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();
}
function markSaved(text='本地已保存'){const el=$('#save-state');if(!el)return;el.textContent=text;clearTimeout(markSaved.timer);markSaved.timer=setTimeout(()=>el.textContent='本地已保存',2200);}

function bind(){
  $$('.nav-link').forEach(button=>button.addEventListener('click',()=>showPanel(button.dataset.tab)));
  $('#template-select').addEventListener('change',event=>selectTemplate(event.target.value));
  $('#template-name').addEventListener('input',event=>{if(!state.template)return;state.template.name=event.target.value.trim()||'未命名模板';setTemplateDirty('名称待保存');renderLayout();});
  $('#save-template-name').addEventListener('click',saveTemplateName);
  $('#new-template').addEventListener('click',createTemplate); $('#delete-template').addEventListener('click',deleteCurrentTemplate); $('#product-template-select').addEventListener('change',event=>{state.productTemplateId=event.target.value;persist();renderProducts();});
  $('#save-template').addEventListener('click',()=>saveCurrentTemplate('模板已保存'));
  $('#confirm-template').addEventListener('click',async()=>{if(!state.template)return;const wasConfirmed=state.template.confirmed;state.template.confirmed=true;setTemplateDirty('布局确认待保存');const saved=await saveCurrentTemplate('布局已确认并保存');if(!saved)state.template.confirmed=wasConfirmed;renderLayout();});
  $('#reset-template').addEventListener('click',resetCurrentTemplate);
  $('#analyze-layout').addEventListener('click',()=>{const file=$('#template-file')?.files?.[0];if(file)analyzeLayoutFile(file);else toast('请先上传裁片布局图');});
  $('#template-file').addEventListener('change',event=>{const file=event.target.files?.[0];if(file){$('#template-help')?.setAttribute('data-file',file.name);toast(`已选择 ${file.name}，请点击“重新分析已上传图”`);}});
  $('#clear-layout-source')?.addEventListener('click',clearLayoutSource);
  $('#template-preview').addEventListener('click',()=>download(`/api/download/template-preview?template_id=${encodeURIComponent(state.template?.id||'')}`,'layout-numbered.jpg'));
  $('#download-numbered').addEventListener('click',()=>download(`/api/download/template-preview?template_id=${encodeURIComponent(state.template?.id||'')}`,'layout-numbered.jpg'));
  $('#download-package').addEventListener('click',()=>download(`/api/download/samples.zip?template_id=${encodeURIComponent(state.template?.id||'')}`,'print-material-samples.zip'));
  $('#clean-preview-toggle').addEventListener('click',()=>{state.cleanSample=!state.cleanSample;$('#clean-preview-toggle').textContent=state.cleanSample?'显示编号预览':'显示清洁预览';renderSamples();});
  $('#photo-files').addEventListener('change',event=>uploadProducts([...event.target.files]));
  $('#folder-files').addEventListener('change',event=>{if(!$('#folder-mode').checked)$('#folder-mode').checked=true;uploadProducts([...event.target.files]);});
  $('#photo-drop').addEventListener('dragover',event=>{event.preventDefault();$('#photo-drop').style.borderColor='#5a9672';});
  $('#photo-drop').addEventListener('dragleave',()=>$('#photo-drop').style.borderColor='');
  $('#photo-drop').addEventListener('drop',event=>{event.preventDefault();uploadProducts([...event.dataTransfer.files]);});
  $('#prepare-surface').addEventListener('click',prepareSurface);$('#open-chatgpt-task').addEventListener('click',openChatGPTTask);$('#approve-surface').addEventListener('click',approveSurface); $('#start-generation').addEventListener('click',startGeneration); $('#export-chatgpt-task').addEventListener('click',exportChatGPTTask); $('#import-generated-result').addEventListener('change',event=>importGeneratedResult(event.target.files[0]));
  $('#clear-products').addEventListener('click',()=>{state.products=[];renderProducts();persist();toast('商品清单已清空');});
  $('#texture-toggle').addEventListener('click',event=>{state.texture=!state.texture;event.currentTarget.classList.toggle('active',state.texture);persist();});
  $('#mirror-toggle').addEventListener('click',event=>{state.mirror=!state.mirror;event.currentTarget.classList.toggle('active',state.mirror);persist();});
  $('#refresh-jobs').addEventListener('click',loadJobs); $('#settings-open').addEventListener('click',openSettings); $('#settings-close').addEventListener('click',()=>$('#settings-dialog').classList.add('hidden')); $('.modal-backdrop').addEventListener('click',()=>$('#settings-dialog').classList.add('hidden')); $('#help-button').addEventListener('click',()=>toast('流程：上传布局 → 生成新草稿 → 核对部件 → 保存并确认 → 上传商品 → 生成与审核'));
  $('#settings-form').addEventListener('submit',async event=>{event.preventDefault();if(PREVIEW){toast('独立预览不会保存本机设置');return;}const payload={api_key:$('#api-key').value.trim(),model:$('#model').value.trim(),daily_calls:$('#daily-calls').value,daily_budget:$('#daily-budget').value};try{state.api=await api('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});$('#settings-dialog').classList.add('hidden');$('#model-state').textContent=state.api.configured?'已配置，可生成':'未配置 API 密钥';$('#model-state').className=`pill ${state.api.configured?'':'warning'}`;$('#api-key').value='';$('#api-key').placeholder=state.api.configured?'已配置，留空表示保持不变':'输入本机 API 密钥';toast('本机设置已保存');}catch(error){toast(error.message||'本机设置保存失败');}});
  document.addEventListener('keydown',event=>{if(event.target.closest('input,textarea,select,[contenteditable]'))return;if(event.key>='1'&&event.key<='4')showPanel(['templates','products','samples','jobs'][Number(event.key)-1]);if(event.key==='Escape')$('#settings-dialog').classList.add('hidden');});
}
function showPanel(name){$$('.panel').forEach(panel=>panel.classList.toggle('active',panel.dataset.panel===name));$$('.nav-link').forEach(nav=>nav.classList.toggle('active',nav.dataset.tab===name));if(name==='samples')loadSamples();if(name==='jobs')loadJobs();}
async function init(){bind();await loadTemplates();await loadStatus();await loadProducts();await loadSamples();await loadJobs();if(PREVIEW)renderSamples();}
init();
