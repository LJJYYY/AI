"""Build grounded manual tasks; never substitute a missing product or part."""
import hashlib
from io import BytesIO
import json
from pathlib import Path
import re
import zipfile

from PIL import Image, ImageOps, ImageStat
from .provider import build_prompt

TASK_VERSION = 'all-parts-source-evidence-v3'


class TaskError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def prepare_task(payload, templates, product_root, output_root):
    template = next((t for t in templates if t['id'] == payload.get('template_id')), None)
    if not template:
        raise TaskError('模板不存在，请重新选择模板', 404)
    if not template.get('confirmed'):
        raise TaskError('请先保存并确认商品绑定的模板', 409)
    scope = payload.get('scope', 'single' if payload.get('part_id') else 'all')
    if scope not in {'all', 'single'}:
        raise TaskError('处理范围无效')
    parts = list(template.get('parts', []))
    if scope == 'single':
        parts = [p for p in parts if p['id'] == str(payload.get('part_id', ''))]
    if not parts:
        raise TaskError('所选部件不在当前模板中，未使用默认部件代替', 404)
    if any(not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', p['id']) for p in parts) or len({p['id'] for p in parts}) != len(parts):
        raise TaskError('裁片编号必须唯一，且仅含字母、数字、下划线或短横线')
    part_ids = {p['id'] for p in parts}
    part_prompts = []
    for part in parts:
        source_part = next((p for p in template['parts'] if p['id'] == part.get('mirrorSource')), None)
        mirror = bool(payload.get('mirror') or part.get('mirror'))
        if mirror and (not source_part or source_part['id'] == part['id']):
            raise TaskError(f"{part['id']} 号启用了镜像，但未选择有效来源部件", 409)
        part_prompts.append({'part_id': part['id'], 'prompt': build_prompt(
            part, texture=bool(payload.get('texture') or part.get('keepTexture')),
            mirror=mirror, source_name=f"{source_part['id']} {source_part['name']}" if source_part else None)})
    ids = payload.get('product_ids')
    if not isinstance(ids, list) or not ids or any(not isinstance(value, str) for value in ids):
        raise TaskError('请先选择商品')
    ids = list(dict.fromkeys(ids))
    files, products, tasks = [], [], []
    records = []
    for path in sorted(output_root.glob('material-*/meta.json')):
        try:
            records.append((json.loads(path.read_text(encoding='utf-8')), path.parent))
        except (OSError, ValueError):
            continue
    for product_id in ids:
        if not re.fullmatch(r'product-[A-Za-z0-9-]+', product_id):
            raise TaskError('商品标识无效')
        folder = product_root / product_id
        try:
            meta = json.loads((folder / 'meta.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            raise TaskError(f'商品不存在：{product_id}', 404)
        if meta.get('template_id') != template['id']:
            raise TaskError(f"商品 {meta.get('name', product_id)} 绑定了其他模板，请按模板分批导出", 409)
        images = []
        for filename in meta.get('files', []):
            path = folder / Path(filename).name
            if not path.is_file():
                raise TaskError(f'商品原图缺失：{product_id}/{filename}', 404)
            with Image.open(path) as source:
                size = list(ImageOps.exif_transpose(source).size)
            archive_path = f'products/{product_id}/{path.name}'
            images.append({'file': archive_path, 'size_px': size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
            files.append((path, archive_path))
        if not images:
            raise TaskError(f'商品没有原图：{product_id}', 400)
        regions = []
        approved = {}
        for record, record_folder in records:
            if (record.get('template_id') != template['id'] or record.get('product_id') != product_id
                    or record.get('part_id') not in part_ids):
                continue
            if record.get('status') == 'approved' and (record_folder / 'material.jpg').is_file():
                approved[record['part_id']] = (record, record_folder / 'material.jpg')
            plan = record.get('plan') or {}
            if plan.get('quad'):
                filename = plan.get('filename') or meta.get('front')
                if filename not in meta.get('files', []):
                    continue
                regions.append({'part_id': record['part_id'], 'source_file': f'products/{product_id}/{Path(filename).name}',
                                'quad_px': plan['quad'], 'exclusions': plan.get('exclusions', []),
                                'coordinate_space': 'EXIF-oriented original pixels',
                                'status': 'approved' if record.get('status') == 'approved' else 'draft_needs_verification'})
        products.append({'product_id': product_id, 'name': meta.get('name', product_id),
                         'images': images, 'source_regions': regions})
        for part in parts:
            task = {'product_id': product_id, 'part_id': part['id'], 'part_name': part['name'],
                    'size_px': part['export_size_px'], 'output_file': f"materials/{product_id}/{part['id']}.jpg",
                    'status': 'pending'}
            if part['id'] in approved:
                record, image_path = approved[part['id']]
                reference = f"approved/{product_id}/{part['id']}.jpg"
                files.append((image_path, reference))
                task.update(status='reuse_approved', approved_file=reference, material_id=record.get('id') or image_path.parent.name)
            tasks.append(task)
    total = len(tasks)
    reused = sum(t['status'] == 'reuse_approved' for t in tasks)
    context = {'task_version': TASK_VERSION, 'template_id': template['id'], 'template_name': template['name'],
               'scope': scope, 'parts': parts, 'part_ids': [p['id'] for p in parts], 'products': products,
               'tasks': tasks, 'total_tasks': total, 'reuse_approved_count': reused,
               'generate_count': total - reused, 'result_report_format': {'results': [
                   {'product_id': ids[0], 'part_id': parts[0]['id'], 'status': 'completed | needs_source | reuse_approved',
                    'output_file': tasks[0]['output_file'], 'source_file': 'products/商品ID/原图文件名', 'source_region': '原图像素坐标/已保存标注', 'reason': '缺来源时写具体范围'}]},
               'source_rule': '只使用 products 目录中的商品原图。source_box 是布局图坐标，不是商品图坐标。',
               'missing_source_policy': 'needs_source; 禁止底色占位、虚构花纹或把缺失款式写成已完成',
               'completion_policy': '逐款提供可核对的来源及补全记录；结果必须回到工作台人工审核'}
    if scope == 'single':
        context.update(part_id=parts[0]['id'], part=parts[0])
    prompt = (f"任务协议 {TASK_VERSION}。本批 {len(products)} 款商品 × {len(parts)} 块裁片，共 {total} 项；范围：{'全部裁片' if scope == 'all' else '指定单块重做'}。\n"
              '必须逐款遍历 tasks 中的全部裁片，不得只做 01 领子或当前选中的一块，不得每完成一块就询问是否继续。\n'
              '按商品分组输出所有独立矩形 JPG，严格使用每项 output_file 路径和 size_px。另交 result-report.json，根对象是 {"results": [...]}，每个商品/裁片恰好一条记录。\n'
              '有 approved_file 的项目直接复用已审核文件，不重新生成。依赖镜像来源时先处理来源部件。来源不足的单块标记 needs_source 并说明原因，其余可处理项目继续完成；不能用色块凑齐。\n'
              '若本轮输出或时间限制无法一次完成，保留已完成文件和完整进度报告，标明剩余项可继续同一任务；不得把部分结果声称为全部完成。\n'
              '只把 products 目录内文件当作商品花纹来源；template.json/part.json 的坐标和 source_box 只属于裁片布局图，不能直接用于裁商品图。\n'
              '如有 source_regions，优先读取其中已批准的坐标；草稿坐标须核对是否含手、内搭或相邻部件。已保存范围和规则不要反复确认；只有真实缺少的部件来源才标记 needs_source。\n'
              + '\n\n'.join(p['prompt'] for p in part_prompts) + '\n\n以下是本次任务完整清单（逐款逐块处理，不得省略）：\n'
              + json.dumps(context, ensure_ascii=False, indent=2))
    launch_prompt = (f"请执行我将上传的裁片任务 ZIP：{len(products)} 款商品 × {len(parts)} 块裁片，共 {total} 项，{'全部裁片' if scope == 'all' else '单块重做'}。"
                     '先读取 prompt.txt 和 manifest.json，完整规则及商品来源均在包内。只提取商品图可见像素并校正透视，遮挡处局部补全；禁止整块重绘或底色占位。'
                     '逐款处理清单中的所有裁片，不要只做领子，也不要逐块要求确认；缺少来源的单块标记 needs_source，其余继续。复用已审核结果，交付全部 JPG 和完整来源/进度报告。')
    return {'manifest': context, 'prompt': prompt, 'launch_prompt': launch_prompt,
            'template': template, 'part': parts[0] if scope == 'single' else None,
            'parts': parts, 'part_prompts': part_prompts, 'files': files}


def task_zip(task):
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, value in [('manifest.json', task['manifest']), ('template.json', task['template']), ('parts.json', task['parts'])]:
            archive.writestr(name, json.dumps(value, ensure_ascii=False, indent=2))
        if task['part']:
            archive.writestr('part.json', json.dumps(task['part'], ensure_ascii=False, indent=2))
        for part_prompt in task['part_prompts']:
            archive.writestr(f"part-prompts/{part_prompt['part_id']}.txt", part_prompt['prompt'])
        archive.writestr('prompt.txt', task['prompt'])
        archive.writestr('instructions.txt', '直接执行 prompt.txt 和 manifest.json。已知规则无需再次确认。缺少部件来源时，标记 needs_source 并说明具体缺失范围，禁止输出纯色色条或占位图凑数。结果均需审核。\n')
        for source, name in task['files']:
            archive.write(source, name)
    return buffer.getvalue()


def inspect_result(uploaded, expected_size, plain_confirmed=False):
    try:
        with Image.open(BytesIO(uploaded)) as source:
            image = ImageOps.exif_transpose(source).convert('RGB')
    except (OSError, ValueError, Image.DecompressionBombError):
        raise TaskError('结果不是可读取的图片', 422)
    if list(image.size) != list(expected_size):
        raise TaskError(f"原生尺寸 {image.width} × {image.height} 不符合当前部件要求 {expected_size[0]} × {expected_size[1]}；不会拉伸图片冒充合格结果", 422)
    extrema = image.getextrema()
    nearly_plain = all(high - low <= 8 for low, high in extrema) or max(ImageStat.Stat(image).stddev) < 1.2
    if nearly_plain and not plain_confirmed:
        raise TaskError('图片接近纯色，可能是底色占位图，已阻止导入。只有核对商品原图中该部件确为素色后，才可勾选“原部件确为素色”重新导入；花纹部件需要重新处理', 422)
    return image, {'nearly_plain': nearly_plain, 'plain_source_confirmed': bool(plain_confirmed),
                   'source_fidelity': 'requires_human_review'}


def inspect_result_batch(uploaded, task):
    """Match every product/part explicitly; return drafts and all missing items."""
    try:
        archive = zipfile.ZipFile(BytesIO(uploaded))
    except zipfile.BadZipFile:
        raise TaskError('结果 ZIP 无法读取', 422)
    with archive:
        infos = archive.infolist()
        if len(infos) > 5000 or sum(i.file_size for i in infos) > 1024 * 1024 * 1024:
            raise TaskError('结果包过大，请按商品分包导入', 422)
        if len({i.filename for i in infos}) != len(infos):
            raise TaskError('结果 ZIP 有重复文件名，无法可靠对应裁片', 422)
        try:
            report = json.loads(archive.read('result-report.json'))
            entries = report['results']
        except (KeyError, ValueError, TypeError, RuntimeError, zipfile.BadZipFile):
            raise TaskError('结果包需要根目录 result-report.json，格式见任务包中的 result_report_format', 422)
        if not isinstance(entries, list) or any(not isinstance(e, dict) for e in entries):
            raise TaskError('结果报告 results 必须是列表', 422)
        expected = {(t['product_id'], t['part_id']): t for t in task['manifest']['tasks']}
        sources = {p['product_id']: {i['file'] for i in p['images']} for p in task['manifest']['products']}
        reports, duplicates = {}, set()
        for entry in entries:
            key = (entry.get('product_id'), entry.get('part_id'))
            if not all(isinstance(v, str) for v in key) or key not in expected:
                raise TaskError('结果报告包含当前模板/商品清单以外的部件，请核对任务包', 409)
            if key in reports:
                duplicates.add(key)
            reports[key] = entry
        results, drafts = [], []
        for key, item in expected.items():
            row = {**item}
            entry = reports.get(key)
            if item['status'] == 'reuse_approved':
                row.update(status='reused_approved', reason='沿用已审核素材，未覆盖')
            elif key in duplicates:
                row.update(status='invalid_result', reason='同一商品/裁片在报告中重复')
            elif not entry:
                row.update(status='missing_report', reason='未交付该项报告，未计为完成')
            elif entry.get('status') == 'needs_source':
                row.update(status='needs_source', reason=str(entry.get('reason') or '缺少对应部件来源'))
            elif entry.get('status') != 'completed':
                row.update(status='incomplete', reason=str(entry.get('reason') or '该项尚未完成'))
            elif entry.get('source_file') not in sources[key[0]] or not entry.get('source_region'):
                row.update(status='invalid_result', reason='缺少该款商品的原图来源及区域说明')
            elif entry.get('output_file', item['output_file']) != item['output_file']:
                row.update(status='invalid_result', reason='输出路径与任务清单不一致')
            else:
                try:
                    image_bytes = archive.read(item['output_file'])
                    image, validation = inspect_result(image_bytes, item['size_px'])
                except (KeyError, TaskError, OSError, RuntimeError, zipfile.BadZipFile) as error:
                    row.update(status='invalid_result', reason=str(error))
                else:
                    row.update(status='needs_review', reason='尺寸检查通过，仍需对照原图审核')
                    image.close()
                    drafts.append({'row': row, 'image_bytes': image_bytes, 'validation': validation, 'source_report': entry})
            results.append(row)
    return {'results': results, 'drafts': drafts, 'total': len(results)}
