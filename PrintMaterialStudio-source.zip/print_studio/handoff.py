"""Build grounded manual tasks; never substitute a missing product or part."""
import hashlib
from io import BytesIO
import json
from pathlib import Path
import zipfile

from PIL import Image, ImageOps, ImageStat
from .provider import build_prompt

TASK_VERSION = 'source-evidence-v2'


class TaskError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def prepare_task(payload, templates, product_root, output_root):
    template = next((t for t in templates if t['id'] == payload.get('template_id')), None)
    if not template:
        raise TaskError('模板不存在，请重新选择模板', 404)
    if not template.get('confirmed'):
        raise TaskError('请先保存并确认商品绑定的模板', 409)
    part = next((p for p in template.get('parts', []) if p['id'] == str(payload.get('part_id', ''))), None)
    if not part:
        raise TaskError('所选部件不在当前模板中，未使用默认部件代替', 404)
    ids = payload.get('product_ids')
    if not isinstance(ids, list) or not ids or any(not isinstance(value, str) for value in ids):
        raise TaskError('请先选择商品')
    ids = list(dict.fromkeys(ids))
    files, products = [], []
    for product_id in ids:
        if Path(product_id).name != product_id or not product_id.startswith('product-'):
            raise TaskError('商品标识无效')
        folder = product_root / product_id
        try:
            meta = json.loads((folder / 'meta.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            raise TaskError(f'商品不存在：{product_id}', 404)
        if meta.get('template_id') != template['id']:
            raise TaskError(f"商品 {meta.get('name', product_id)} 绑定了其他模板，请按模板分批导出", 409)
        images = []
        for filename in meta.get('files', []):
            path = folder / Path(filename).name
            if not path.is_file():
                raise TaskError(f'商品原图缺失：{product_id}/{filename}', 404)
            with Image.open(path) as source:
                size = list(ImageOps.exif_transpose(source).size)
            archive_path = f'products/{product_id}/{path.name}'
            images.append({'file': archive_path, 'size_px': size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
            files.append((path, archive_path))
        if not images:
            raise TaskError(f'商品没有原图：{product_id}', 400)
        regions = []
        for record_path in sorted(output_root.glob('material-*/meta.json')):
            try:
                record = json.loads(record_path.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                continue
            plan = record.get('plan') or {}
            if (record.get('template_id') == template['id'] and record.get('product_id') == product_id
                    and record.get('part_id') == part['id'] and plan.get('quad')):
                filename = plan.get('filename') or meta.get('front')
                if filename not in meta.get('files', []):
                    continue
                regions.append({'source_file': f'products/{product_id}/{Path(filename).name}',
                                'quad_px': plan['quad'], 'exclusions': plan.get('exclusions', []),
                                'coordinate_space': 'EXIF-oriented original pixels',
                                'status': 'approved' if record.get('status') == 'approved' else 'draft_needs_verification'})
        products.append({'product_id': product_id, 'name': meta.get('name', product_id),
                         'images': images, 'source_regions': regions})
    source_part = next((p for p in template['parts'] if p['id'] == part.get('mirrorSource')), None)
    mirror = bool(payload.get('mirror') or part.get('mirror'))
    if mirror and not source_part:
        raise TaskError('启用了镜像，但未选择有效的来源部件，请先保存来源部件', 409)
    prompt = build_prompt(part, texture=bool(payload.get('texture') or part.get('keepTexture')),
                          mirror=mirror, source_name=f"{source_part['id']} {source_part['name']}" if source_part else None)
    context = {'task_version': TASK_VERSION, 'template_id': template['id'], 'template_name': template['name'],
               'part_id': part['id'], 'part': part, 'products': products,
               'source_rule': '只使用 products 目录中的商品原图。source_box 是布局图坐标，不是商品图坐标。',
               'missing_source_policy': 'needs_source; 禁止底色占位、虚构花纹或把缺失款式写成已完成',
               'completion_policy': '逐款提供可核对的来源及补全记录；结果必须回到工作台人工审核'}
    prompt = (f"任务协议 {TASK_VERSION}。执行 {template['name']} 模板的当前部件，本批 {len(products)} 款。\n"
              '只把 products 目录内文件当作商品花纹来源；template.json/part.json 的坐标和 source_box 只属于裁片布局图，不能直接用于裁商品图。\n'
              '如有 source_regions，优先读取其中已批准的坐标；草稿坐标须核对是否含手、内搭或相邻部件。已保存范围和规则不要反复确认；只有真实缺少的部件来源才标记 needs_source。\n'
              + prompt + '\n\n以下是本次任务完整清单（逐款处理，不得省略）：\n'
              + json.dumps(context, ensure_ascii=False, indent=2))
    launch_prompt = (f"请执行我将上传的裁片任务 ZIP，当前部件 {part['id']} {part['name'][:40]}。"
                     '先读取 prompt.txt 和 manifest.json，完整规则及商品来源均在包内。只提取商品图可见像素并校正透视，遮挡处局部补全；禁止整块重绘或底色占位。'
                     '已确认规则无需再问；来源不足须标记 needs_source，不输出伪成品。逐款交付 JPG 和来源报告。')
    return {'manifest': context, 'prompt': prompt, 'launch_prompt': launch_prompt,
            'template': template, 'part': part, 'files': files}


def task_zip(task):
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, value in [('manifest.json', task['manifest']), ('template.json', task['template']), ('part.json', task['part'])]:
            archive.writestr(name, json.dumps(value, ensure_ascii=False, indent=2))
        archive.writestr('prompt.txt', task['prompt'])
        archive.writestr('instructions.txt', '直接执行 prompt.txt 和 manifest.json。已知规则无需再次确认。缺少部件来源时，标记 needs_source 并说明具体缺失范围，禁止输出纯色色条或占位图凑数。结果均需审核。\n')
        for source, name in task['files']:
            archive.write(source, name)
    return buffer.getvalue()


def inspect_result(uploaded, expected_size, plain_confirmed=False):
    try:
        with Image.open(BytesIO(uploaded)) as source:
            image = ImageOps.exif_transpose(source).convert('RGB')
    except (OSError, ValueError):
        raise TaskError('结果不是可读取的图片', 422)
    if list(image.size) != list(expected_size):
        raise TaskError(f"原生尺寸 {image.width} × {image.height} 不符合当前部件要求 {expected_size[0]} × {expected_size[1]}；不会拉伸图片冒充合格结果", 422)
    extrema = image.getextrema()
    nearly_plain = all(high - low <= 8 for low, high in extrema) or max(ImageStat.Stat(image).stddev) < 1.2
    if nearly_plain and not plain_confirmed:
        raise TaskError('图片接近纯色，可能是底色占位图，已阻止导入。只有核对商品原图中该部件确为素色后，才可勾选“原部件确为素色”重新导入；花纹部件需要重新处理', 422)
    return image, {'nearly_plain': nearly_plain, 'plain_source_confirmed': bool(plain_confirmed),
                   'source_fidelity': 'requires_human_review'}
