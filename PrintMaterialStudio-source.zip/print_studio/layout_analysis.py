"""Geometry-only layout detection on light nesting-sheet backgrounds.

Preserve narrow paper gaps: never dilate the foreground or substitute a garment
preset when detection fails. Coordinates returned here are original-image pixels.
"""
from __future__ import annotations

import io
import re
from PIL import Image, ImageChops, ImageOps

ANALYSIS_VERSION = 'layout-runs-v2'
MAX_SIDE = 2400


def detect_layout_regions(data: bytes) -> tuple[list[tuple[int, int, int, int, int]], dict]:
    with Image.open(io.BytesIO(data)) as original:
        image = ImageOps.exif_transpose(original).convert('RGBA')
    paper = Image.new('RGBA', image.size, 'white')
    paper.alpha_composite(image)
    image = paper.convert('RGB')
    sw, sh = image.size
    image.thumbnail((MAX_SIDE, MAX_SIDE), Image.Resampling.LANCZOS)
    width, height = image.size
    r, g, b = image.split()
    darkest = ImageChops.darker(ImageChops.darker(r, g), b)
    # Components are separated by near-white paper. In particular, no max-filter
    # or dilation may bridge the 1-3 pixel gaps after reduction.
    foreground = darkest.point(lambda pixel: 255 if pixel < 235 else 0).tobytes()
    parents: list[int] = []
    stats: list[list[int]] = []

    def root(index):
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    def merge(a, b):
        a, b = root(a), root(b)
        if a == b:
            return a
        # Attach to older root to keep trees shallow; both boxes are accumulated.
        a, b = min(a, b), max(a, b)
        parents[b] = a
        sa, sb = stats[a], stats[b]
        sa[:] = [min(sa[0], sb[0]), min(sa[1], sb[1]), max(sa[2], sb[2]), max(sa[3], sb[3]), sa[4] + sb[4]]
        return a

    previous = []
    for y in range(height):
        current = []
        row = foreground[y * width:(y + 1) * width]
        previous_index = 0
        for match in re.finditer(b'\xff+', row):
            x0, x1 = match.span()
            while previous_index < len(previous) and previous[previous_index][1] <= x0:
                previous_index += 1
            label = None
            index = previous_index
            while index < len(previous) and previous[index][0] < x1:
                label = root(previous[index][2]) if label is None else merge(label, previous[index][2])
                index += 1
            if label is None:
                label = len(parents)
                parents.append(label)
                stats.append([x0, y, x1, y + 1, x1 - x0])
            else:
                label = root(label)
                box = stats[label]
                box[:] = [min(box[0], x0), box[1], max(box[2], x1), y + 1, box[4] + x1 - x0]
            current.append((x0, x1, label))
        previous = current

    minimum_area = max(36, int(width * height * .0012))
    regions = []
    for index, (x0, y0, x1, y1, area) in enumerate(stats):
        if parents[index] != index or area < minimum_area or x1-x0 < 4 or y1-y0 < 4:
            continue
        # An almost full-sheet component is an unsupported background/merged sheet,
        # not evidence for a single huge garment or the old XGV preset.
        if (x1-x0)*(y1-y0) > width*height*.98 and area > width*height*.85:
            continue
        regions.append((round(x0*sw/width), round(y0*sh/height), min(sw, round(x1*sw/width)), min(sh, round(y1*sh/height)), round(area*sw*sh/(width*height))))
    regions.sort(key=lambda box: (box[1], box[0]))
    return regions, {'width': sw, 'height': sh, 'analysis_width': width, 'analysis_height': height,
                     'detected_count': len(regions), 'analysis_method': ANALYSIS_VERSION,
                     'analysis_status': 'candidates' if regions else 'no_regions',
                     'source_boxes': [list(box[:4]) for box in regions]}
