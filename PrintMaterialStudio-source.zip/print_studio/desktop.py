"""Own the local service, its single-instance lock, and a Windows tray icon."""
from __future__ import annotations

import argparse
import hmac
import json
import os
from pathlib import Path
import secrets
import sys
import threading
import time
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, Request, build_opener
import webbrowser

APP_ID = "print-material-studio-desktop"
DEFAULT_PORT = 18765
HTTP = build_opener(ProxyHandler({}))


def data_directory(override=None):
    if override or os.environ.get("PRINT_STUDIO_DATA"):
        return Path(override or os.environ["PRINT_STUDIO_DATA"]).expanduser().resolve()
    if getattr(sys, "frozen", False):
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local" / "share"))
        return base / "PrintMaterialStudio" / "data"
    return Path(__file__).resolve().parents[1] / ".local-data"


class InstanceLock:
    def __init__(self, path):
        self.path = Path(path)
        self.handle = None

    def acquire(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.path.open("a+b")
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            handle.close()
            return False
        self.handle = handle
        return True

    def release(self):
        if self.handle:
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close()
            self.handle = None


def read_session(path):
    try:
        session = json.loads(Path(path).read_text(encoding="utf-8"))
        url = urlsplit(session["url"])
        if (session.get("app") == APP_ID and url.scheme == "http"
                and url.hostname == "127.0.0.1" and url.port
                and not url.username and not url.password and not url.path
                and not url.query and not url.fragment and session.get("instance")):
            return session
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return None


def session_is_live(session):
    if not session:
        return False
    try:
        with HTTP.open(session["url"] + "/__desktop/health", timeout=1) as response:
            health = json.loads(response.read(16384))
        return health.get("app") == APP_ID and health.get("instance") == session["instance"]
    except (OSError, URLError, ValueError, TypeError):
        return False


def wait_for_session(path, timeout=20):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        session = read_session(path)
        if session_is_live(session):
            return session
        time.sleep(0.1)
    raise RuntimeError("工作台正在启动，请稍后再双击图标。若仍无法打开，请查看数据目录中的 desktop.log。")


def create_server(port, session):
    from http.server import ThreadingHTTPServer
    from .app import Handler

    class DesktopHandler(Handler):
        def do_GET(self):
            if self.path == "/__desktop/health":
                return self.send_json({"app": APP_ID, "instance": session["instance"]})
            return super().do_GET()

        def do_POST(self):
            if self.path == "/__desktop/quit":
                expected = "Bearer " + session["token"]
                if not hmac.compare_digest(self.headers.get("Authorization", ""), expected):
                    return self.send_json({"error": "forbidden"}, 403)
                self.send_json({"stopping": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return super().do_POST()

    class LocalServer(ThreadingHTTPServer):
        allow_reuse_address = False
        daemon_threads = True

        def server_bind(self):
            if os.name == "nt":
                import socket
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            super().server_bind()

    for candidate in ([0] if port == 0 else range(port, min(port + 10, 65536))):
        try:
            return LocalServer(("127.0.0.1", candidate), DesktopHandler)
        except OSError as error:
            if error.errno not in {48, 98, 10013, 10048} and getattr(error, "winerror", None) not in {10013, 10048}:
                raise
    # The OS selects a free local port if every preferred port was already used.
    return LocalServer(("127.0.0.1", 0), DesktopHandler)


def tray_icon(url, directory, shutdown):
    import pystray
    from PIL import Image, ImageDraw

    image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((2, 2, 62, 62), radius=16, fill="#3c6b5a")
    draw.rectangle((17, 17, 24, 48), fill="white")
    draw.rounded_rectangle((20, 17, 48, 36), radius=7, fill="white")
    draw.rectangle((25, 24, 39, 29), fill="#3c6b5a")

    def open_workbench(icon=None, item=None):
        webbrowser.open(url)

    def open_data(icon=None, item=None):
        os.startfile(str(directory))

    def exit_workbench(icon, item):
        shutdown()
        icon.stop()

    return pystray.Icon(APP_ID, image, "裁片素材工作台", pystray.Menu(
        pystray.MenuItem("打开工作台", open_workbench, default=True),
        pystray.MenuItem("打开数据文件夹", open_data),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("退出工作台", exit_workbench),
    ))


def run(args):
    directory = data_directory(args.data_dir)
    directory.mkdir(parents=True, exist_ok=True)
    os.environ["PRINT_STUDIO_DATA"] = str(directory)
    os.environ["PRINT_STUDIO_QUIET"] = "1"
    # PyInstaller --windowed deliberately leaves these streams unset.
    if sys.stdout is None or sys.stderr is None:
        log = (directory / "desktop.log").open("a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log
    record = directory / "desktop-session.json"
    if args.quit:
        session = read_session(record)
        if session_is_live(session):
            request = Request(session["url"] + "/__desktop/quit", data=b"",
                              headers={"Authorization": "Bearer " + session["token"]})
            with HTTP.open(request, timeout=5) as response:
                response.read()
        return 0
    lock = InstanceLock(directory / "desktop.lock")
    if not lock.acquire():
        session = wait_for_session(record)
        if not args.no_browser:
            webbrowser.open(session["url"])
        return 0

    server = None
    thread = None
    session = {"app": APP_ID, "instance": secrets.token_hex(16), "token": secrets.token_hex(32)}
    try:
        from .app import ensure_data, write_preview_artifacts, write_json
        ensure_data()
        write_preview_artifacts()
        server = create_server(args.port, session)
        session.update(url=f"http://127.0.0.1:{server.server_port}", pid=os.getpid())
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        write_json(record, session)
        wait_for_session(record)
        if not args.no_browser:
            webbrowser.open(session["url"])
        if args.headless:
            thread.join()
        else:
            icon = tray_icon(session["url"], directory, server.shutdown)
            threading.Thread(target=lambda: (thread.join(), icon.stop()), daemon=True).start()
            icon.run()
    finally:
        if server:
            server.shutdown()
            server.server_close()
        if thread:
            thread.join(timeout=5)
        saved = read_session(record)
        if saved and saved.get("instance") == session["instance"]:
            record.unlink(missing_ok=True)
        lock.release()
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description="裁片素材工作台桌面程序")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--data-dir")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--headless", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--quit", action="store_true", help="退出本桌面程序启动的工作台")
    args = parser.parse_args(argv)
    if not 0 <= args.port <= 65535:
        parser.error("port must be between 0 and 65535")
    try:
        return run(args)
    except Exception:
        import traceback
        directory = data_directory(args.data_dir)
        directory.mkdir(parents=True, exist_ok=True)
        with (directory / "desktop.log").open("a", encoding="utf-8") as log:
            traceback.print_exc(file=log)
        if os.name == "nt" and not args.headless:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, f"启动失败。请查看日志：\n{directory / 'desktop.log'}", "裁片素材工作台", 0x10)
        return 1
