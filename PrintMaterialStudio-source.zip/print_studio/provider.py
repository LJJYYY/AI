"""Optional OpenAI image provider.

The web application keeps provider calls behind this module so API keys never enter
browser JavaScript. By default the local app queues jobs without spending credits;
set PRINT_STUDIO_ENABLE_PROVIDER=1 to enable the real request path after reviewing
model, budget and output settings.
"""
from __future__ import annotations

import base64
import json
import os
import urllib.error
import urllib.request
import uuid
from pathlib import Path


def build_prompt(part: dict, texture: bool = False, mirror: bool = False, source_name: str | None = None) -> str:
    motif = "把商品图中该部件可见的花纹像素、颜色、边界、图案大小和相对位置视为锁定内容；可见区域必须直接保留并校正透视，禁止重新绘制或重新排列。"
    geometry = "输出干净的平面矩形素材，保持花纹比例；只在被遮挡、折叠或缺失的区域向外延展，严禁拉伸、整体重排或用新的重复纹样替换原图。"
    hidden = "缺失区域只能根据该部件可见区域四周最近的花纹、颜色、方向和边界连续补全，不得从整件衣服的其他区域重新设计。"
    plain = "只有商品原图中已明确定位的该部件本来就是素色时，才保留其素色；不能根据‘领子/门襟’名称推断素色。无法定位或看不到不等于素色，禁止吸取衣身底色制作纯色色条、色板或占位素材。原部件有花纹时必须保留花纹，不能只保留平均颜色。"
    surface = "保留商品图中的毛绒、褶皱和光影。" if texture else "去掉真实毛绒、褶皱和光影，只保留印花边缘的自然斑驳感。"
    mirror_text = f"按部件 {source_name} 的可见花纹镜像生成。" if mirror and source_name else "不启用镜像。"
    scope = str(part.get('extraction_note') or '').strip()
    definition = f"已保存的部件提取范围：{scope}。" if scope else "部件以当前模板的编号和商品图中可见接缝/边界定位，编号本身不是商品图上的坐标。领子/领条不必是独立的衬衫翻领，也不能擅自与相邻门襟合并。"
    size = part.get('export_size_px')
    output = f"每款商品独立输出 {size[0]} × {size[1]} px 的 JPG，" if isinstance(size, list) and len(size) == 2 else "每款商品独立输出 JPG，"
    failure = "先逐款核对来源证据；若该部件无法定位、缺少可见花纹、遮挡过大或当前工具不能执行像素处理，标记 needs_source（缺少来源）并写明缺失范围，不输出伪成品，不宣称已完成或已通过验证。不得用纯色、任意重复纹理、窄条原图裁切、人物或背景填满目标尺寸。只对信息足够的款式处理；不要重复询问已经写明的工作规则。"
    report = "同时提供 result-report.json，逐款列出 product_id、part_id、status（completed 或 needs_source）、source_file、来源像素坐标/已保存标注、可见图案描述、局部补全范围、输出文件名及原生像素尺寸。只把 completed 的真实结果放入成品目录；几何尺寸正确不代表花纹提取正确。"
    return f"处理裁片 {part.get('id')} {part.get('name')}（穿衣者自身左右），执行像素保真提取而非整块重绘。{definition}{motif}{geometry}{hidden}{plain}{surface}{mirror_text}{output}禁止拼图或合并不同商品。{failure}{report}"


def enabled() -> bool:
    return os.environ.get("PRINT_STUDIO_ENABLE_PROVIDER") == "1"


def generate_image(product_image: Path, part: dict, *, model: str, api_key: str, texture: bool = False, mirror: bool = False, mirror_source: str | None = None) -> dict:
    """Call the image edit endpoint when explicitly enabled.

    The response is returned as metadata; the caller owns storing the decoded image.
    This path is intentionally opt-in because every call can incur provider cost.
    """
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured")
    if not enabled():
        return {"dry_run": True, "part_id": part.get("id"), "prompt": build_prompt(part, texture, mirror, mirror_source)}
    boundary = f"----PrintStudio{uuid.uuid4().hex}"
    data = product_image.read_bytes()
    fields = [("model", model), ("prompt", build_prompt(part, texture, mirror, mirror_source)), ("size", "auto"), ("response_format", "b64_json")]
    chunks = []
    for key, value in fields:
        chunks.extend([f"--{boundary}\r\n".encode(), f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode(), str(value).encode(), b"\r\n"])
    chunks.extend([f"--{boundary}\r\n".encode(), b'Content-Disposition: form-data; name="image"; filename="product.png"\r\n', b"Content-Type: application/octet-stream\r\n\r\n", data, b"\r\n", f"--{boundary}--\r\n".encode()])
    request = urllib.request.Request("https://api.openai.com/v1/images/edits", data=b"".join(chunks), method="POST", headers={"Authorization": f"Bearer {api_key}", "Content-Type": f"multipart/form-data; boundary={boundary}"})
    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            payload = json.loads(response.read())
    except urllib.error.HTTPError as error:
        raise RuntimeError(f"图像服务返回 HTTP {error.code}") from error
    image = payload.get("data", [{}])[0]
    if not image.get("b64_json"):
        raise RuntimeError("图像服务没有返回 b64_json")
    return {"dry_run": False, "part_id": part.get("id"), "bytes": base64.b64decode(image["b64_json"]), "prompt": build_prompt(part, texture, mirror, mirror_source)}
