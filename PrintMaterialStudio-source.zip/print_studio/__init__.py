"""Local print material studio."""
