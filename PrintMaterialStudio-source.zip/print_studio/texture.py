"""Pixel-preserving texture extraction helpers.

This module deliberately does not invent a whole garment print. It keeps the
visible crop as source pixels, normalizes scale without anisotropic stretching,
and marks only the missing area for optional local outpainting.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageChops, ImageDraw, ImageOps, ImageFilter


@dataclass(frozen=True)
class ExtractionPlan:
    source_box: tuple[int, int, int, int]
    target_size: tuple[int, int]
    visible_box: tuple[int, int, int, int]
    missing_box: tuple[int, int, int, int]
    preserves_visible_pixels: bool = True
    generation_scope: str = "missing-area-only"


def clamp_box(box: Iterable[int], width: int, height: int) -> tuple[int, int, int, int]:
    x1, y1, x2, y2 = [int(v) for v in box]
    x1, y1 = max(0, min(x1, width - 1)), max(0, min(y1, height - 1))
    x2, y2 = max(x1 + 1, min(x2, width)), max(y1 + 1, min(y2, height))
    return x1, y1, x2, y2


def _reflect_fill(canvas: Image.Image, box: tuple[int, int, int, int]) -> None:
    """Fill canvas margins around box by reflecting the nearest visible edge."""
    x1, y1, x2, y2 = box
    w, h = canvas.size
    if x1:
        strip = canvas.crop((x1, y1, x2, y2)).transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        strip = strip.crop((max(0, strip.width - x1), 0, strip.width, strip.height))
        canvas.paste(strip.resize((x1, y2 - y1), Image.Resampling.BICUBIC), (0, y1))
    if x2 < w:
        strip = canvas.crop((x1, y1, x2, y2)).transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        strip = strip.crop((0, 0, min(strip.width, w - x2), strip.height))
        canvas.paste(strip.resize((w - x2, y2 - y1), Image.Resampling.BICUBIC), (x2, y1))
    if y1:
        strip = canvas.crop((0, y1, w, y2)).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        strip = strip.crop((0, max(0, strip.height - y1), strip.width, strip.height))
        canvas.paste(strip.resize((w, y1), Image.Resampling.BICUBIC), (0, 0))
    if y2 < h:
        strip = canvas.crop((0, y1, w, y2)).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        strip = strip.crop((0, 0, strip.width, min(strip.height, h - y2)))
        canvas.paste(strip.resize((w, h - y2), Image.Resampling.BICUBIC), (0, y2))


def extract_visible(source: Image.Image, source_box: Iterable[int], target_size: tuple[int, int]) -> tuple[Image.Image, Image.Image, ExtractionPlan]:
    """Extract a visible patch and fit it without changing motif proportions.

    The returned mask is white only where source pixels were pasted. The caller
    may send the black area to a local inpainting/outpainting step; it must not
    regenerate the white area.
    """
    source = source.convert("RGB")
    box = clamp_box(source_box, *source.size)
    patch = source.crop(box)
    tw, th = target_size
    scale = min(tw / patch.width, th / patch.height)
    resized = patch.resize((max(1, round(patch.width * scale)), max(1, round(patch.height * scale))), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (tw, th), "#111827")
    visible = Image.new("L", (tw, th), 0)
    vx, vy = (tw - resized.width) // 2, (th - resized.height) // 2
    canvas.paste(resized, (vx, vy))
    visible.paste(255, (vx, vy, vx + resized.width, vy + resized.height))
    _reflect_fill(canvas, (vx, vy, vx + resized.width, vy + resized.height))
    plan = ExtractionPlan(box, target_size, (vx, vy, vx + resized.width, vy + resized.height), (0, 0, tw, th))
    return canvas, visible, plan


def make_outpaint_mask(visible_mask: Image.Image, feather: int = 8) -> Image.Image:
    """Return a mask where only non-visible pixels may be generated."""
    missing = ImageChops.invert(visible_mask.convert("L"))
    if feather:
        missing = missing.filter(ImageFilter.GaussianBlur(feather))
    return missing


def save_extraction(source_path: Path, output_path: Path, source_box: Iterable[int], target_size: tuple[int, int]) -> ExtractionPlan:
    image = Image.open(source_path)
    material, visible, plan = extract_visible(image, source_box, target_size)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    material.save(output_path, quality=96, subsampling=0)
    visible.save(output_path.with_suffix(".mask.png"))
    return plan


def extract_perspective(source: Image.Image, quad: Iterable[float], target_size: tuple[int, int], *, resample=Image.Resampling.BICUBIC) -> tuple[Image.Image, Image.Image]:
    """Unwarp a visible quadrilateral without color grading or generative redraw.

    ``quad`` is ordered top-left, top-right, bottom-right, bottom-left in source
    image coordinates. The output is the exact pixel projection of that region;
    the white mask marks pixels that came from the visible source.
    """
    points = tuple(float(v) for v in quad)
    if len(points) != 8:
        raise ValueError("quad must contain four x/y pairs")
    image = source.convert("RGB")
    material = image.transform(target_size, Image.Transform.QUAD, points, resample=resample)
    mask = Image.new("L", target_size, 255)
    return material, mask


def fill_mask_from_neighbors(material: Image.Image, visible_mask: Image.Image) -> Image.Image:
    """Fill only masked pixels by reflected neighboring pixels.

    This is a deterministic local fallback for occlusions. It never changes the
    RGB values of visible pixels and never introduces a new palette.
    """
    result = material.convert("RGB").copy()
    mask = visible_mask.convert("L")
    bbox = mask.getbbox()
    if not bbox:
        return result
    _reflect_fill(result, bbox)
    return result
