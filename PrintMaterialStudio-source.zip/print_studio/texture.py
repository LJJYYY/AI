"""Pixel-preserving texture extraction helpers.

This module deliberately does not invent a whole garment print. It keeps the
visible crop as source pixels, normalizes scale without anisotropic stretching,
and marks only the missing area for optional local outpainting.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageChops, ImageDraw, ImageOps, ImageFilter


@dataclass(frozen=True)
class ExtractionPlan:
    source_box: tuple[int, int, int, int]
    target_size: tuple[int, int]
    visible_box: tuple[int, int, int, int]
    missing_box: tuple[int, int, int, int]
    preserves_visible_pixels: bool = True
    generation_scope: str = "missing-area-only"


def clamp_box(box: Iterable[int], width: int, height: int) -> tuple[int, int, int, int]:
    x1, y1, x2, y2 = [int(v) for v in box]
    x1, y1 = max(0, min(x1, width - 1)), max(0, min(y1, height - 1))
    x2, y2 = max(x1 + 1, min(x2, width)), max(y1 + 1, min(y2, height))
    return x1, y1, x2, y2


def _reflect_fill(canvas: Image.Image, box: tuple[int, int, int, int]) -> None:
    """Fill canvas margins around box by reflecting the nearest visible edge."""
    x1, y1, x2, y2 = box
    w, h = canvas.size
    if x1:
        strip = canvas.crop((x1, y1, x2, y2)).transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        strip = strip.crop((max(0, strip.width - x1), 0, strip.width, strip.height))
        canvas.paste(strip.resize((x1, y2 - y1), Image.Resampling.BICUBIC), (0, y1))
    if x2 < w:
        strip = canvas.crop((x1, y1, x2, y2)).transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        strip = strip.crop((0, 0, min(strip.width, w - x2), strip.height))
        canvas.paste(strip.resize((w - x2, y2 - y1), Image.Resampling.BICUBIC), (x2, y1))
    if y1:
        strip = canvas.crop((0, y1, w, y2)).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        strip = strip.crop((0, max(0, strip.height - y1), strip.width, strip.height))
        canvas.paste(strip.resize((w, y1), Image.Resampling.BICUBIC), (0, 0))
    if y2 < h:
        strip = canvas.crop((0, y1, w, y2)).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        strip = strip.crop((0, 0, strip.width, min(strip.height, h - y2)))
        canvas.paste(strip.resize((w, h - y2), Image.Resampling.BICUBIC), (0, y2))


def extract_visible(source: Image.Image, source_box: Iterable[int], target_size: tuple[int, int]) -> tuple[Image.Image, Image.Image, ExtractionPlan]:
    """Extract a visible patch and fit it without changing motif proportions.

    The returned mask is white only where source pixels were pasted. The caller
    may send the black area to a local inpainting/outpainting step; it must not
    regenerate the white area.
    """
    source = source.convert("RGB")
    box = clamp_box(source_box, *source.size)
    patch = source.crop(box)
    tw, th = target_size
    scale = min(tw / patch.width, th / patch.height)
    resized = patch.resize((max(1, round(patch.width * scale)), max(1, round(patch.height * scale))), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (tw, th), "#111827")
    visible = Image.new("L", (tw, th), 0)
    vx, vy = (tw - resized.width) // 2, (th - resized.height) // 2
    canvas.paste(resized, (vx, vy))
    visible.paste(255, (vx, vy, vx + resized.width, vy + resized.height))
    _reflect_fill(canvas, (vx, vy, vx + resized.width, vy + resized.height))
    plan = ExtractionPlan(box, target_size, (vx, vy, vx + resized.width, vy + resized.height), (0, 0, tw, th))
    return canvas, visible, plan


def make_outpaint_mask(visible_mask: Image.Image, feather: int = 8) -> Image.Image:
    """Return a mask where only non-visible pixels may be generated."""
    missing = ImageChops.invert(visible_mask.convert("L"))
    if feather:
        missing = missing.filter(ImageFilter.GaussianBlur(feather))
    return missing


def save_extraction(source_path: Path, output_path: Path, source_box: Iterable[int], target_size: tuple[int, int]) -> ExtractionPlan:
    image = Image.open(source_path)
    material, visible, plan = extract_visible(image, source_box, target_size)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    material.save(output_path, quality=96, subsampling=0)
    visible.save(output_path.with_suffix(".mask.png"))
    return plan


def extract_perspective(source: Image.Image, quad: Iterable[float], target_size: tuple[int, int], *, resample=Image.Resampling.BICUBIC) -> tuple[Image.Image, Image.Image]:
    """Unwarp a visible quadrilateral without color grading or generative redraw.

    ``quad`` is ordered top-left, top-right, bottom-right, bottom-left in source
    image coordinates. The output is the exact pixel projection of that region;
    the white mask marks pixels that came from the visible source.
    """
    image = source.convert("RGB")
    coefficients = _projective_coefficients(quad, target_size)
    material = image.transform(target_size, Image.Transform.PERSPECTIVE, coefficients, resample=resample)
    mask = Image.new("L", target_size, 255)
    return material, mask


def fill_mask_from_neighbors(material: Image.Image, visible_mask: Image.Image) -> Image.Image:
    """Fill only masked pixels by reflected neighboring pixels.

    This is a deterministic local fallback for occlusions. It never changes the
    RGB values of visible pixels and never introduces a new palette.
    """
    result = material.convert("RGB").copy()
    mask = visible_mask.convert("L")
    bbox = mask.getbbox()
    if not bbox:
        return result
    _reflect_fill(result, bbox)
    return result


def _projective_coefficients(quad, target_size):
    """Solve output -> source homography (TL, TR, BR, BL).

    Pillow QUAD uses TL, BL, BR, TR and bilinear interpolation; it is not a
    perspective transform. Use an actual homography to preserve point placement.
    """
    import math
    values = list(map(float, quad))
    if len(values) != 8 or not all(math.isfinite(v) for v in values):
        raise ValueError('必须提供左上、右上、右下、左下四个有效点')
    points=list(zip(values[::2],values[1::2]))
    cross=[]
    for i in range(4):
        a,b,c=points[i],points[(i+1)%4],points[(i+2)%4]
        cross.append((b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0]))
    if min(cross) <= 1e-6:
        raise ValueError('四点必须按左上、右上、右下、左下围成不交叉的部件区域')
    w,h=target_size
    rows=[]
    for (x,y),(u,v) in zip([(0,0),(w,0),(w,h),(0,h)],points):
        rows.append([x,y,1,0,0,0,-u*x,-u*y,u])
        rows.append([0,0,0,x,y,1,-v*x,-v*y,v])
    for col in range(8):
        pivot=max(range(col,8),key=lambda row:abs(rows[row][col]))
        if abs(rows[pivot][col])<1e-12: raise ValueError('部件区域过窄，无法展开')
        rows[col],rows[pivot]=rows[pivot],rows[col]
        divisor=rows[col][col]
        rows[col]=[value/divisor for value in rows[col]]
        for row in range(8):
            if row==col: continue
            factor=rows[row][col]
            rows[row]=[a-factor*b for a,b in zip(rows[row],rows[col])]
    return tuple(row[8] for row in rows)


def rebuild_surface(source, quad, target_size, exclusions=(), repairs=()):
    """Project garment plane, exclude occluders, then clone explicit local donors.

    All rectangles and donor origins are fractions in the flattened output plane.
    No RGB adjustment, free generation or unmasked cropping is performed. Unknown
    areas stay marked until an explicit valid donor covers them. Repairs never
    write into visible pixels and donors may not include unknown/occluded pixels.
    """
    import math
    w,h=map(int,target_size)
    if w<2 or h<2 or w*h>30_000_000: raise ValueError('素材尺寸超出可处理范围')
    if len(quad)!=8: raise ValueError('请先标记部件四点边界')
    for x,y in zip(quad[::2],quad[1::2]):
        if not 0<=x<=source.width or not 0<=y<=source.height:
            raise ValueError('部件边界超出商品图')
    coefficients=_projective_coefficients(quad,(w,h))
    base=source.convert('RGB').transform((w,h),Image.Transform.PERSPECTIVE,coefficients,Image.Resampling.BICUBIC)
    valid=Image.new('L',(w,h),255)
    boxes=[]
    for rect in exclusions:
        if len(rect)!=4 or not all(math.isfinite(float(v)) and 0<=float(v)<=1 for v in rect):
            raise ValueError('遮挡范围必须位于展开图内')
        x0,y0,x1,y1=rect
        box=(round(x0*w),round(y0*h),round(x1*w),round(y1*h))
        if box[2]<=box[0] or box[3]<=box[1]: raise ValueError('遮挡范围不能为空')
        valid.paste(0,box);boxes.append(box)
    original_valid=valid.copy()
    result=base.copy()
    for repair in repairs:
        index=int(repair['index']);dx,dy=map(float,repair['donor'])
        if not 0<=index<len(boxes) or not all(math.isfinite(v) and 0<=v<=1 for v in (dx,dy)):
            raise ValueError('补全来源无效')
        box=boxes[index];bw,bh=box[2]-box[0],box[3]-box[1]
        sx,sy=round(dx*w),round(dy*h);donor_box=(sx,sy,sx+bw,sy+bh)
        if sx+bw>w or sy+bh>h or original_valid.crop(donor_box).getextrema()!=(255,255):
            raise ValueError('补全来源包含遮挡或超出部件，请重新选择附近完整花纹')
        missing=ImageChops.invert(valid.crop(box))
        result.paste(base.crop(donor_box),box,missing);valid.paste(255,box)
    unresolved=valid.histogram()[0]
    # Explicit draft marks, never use source hands/clothing/background as fill.
    result.paste((244,215,225),(0,0,w,h),ImageChops.invert(valid))
    return result,valid,{'unresolved_pixels':unresolved,'status':'needs_completion' if unresolved else 'needs_review','method':'projective-local-clone','visible_area_locked':True}
