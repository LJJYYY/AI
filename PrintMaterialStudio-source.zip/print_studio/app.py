from __future__ import annotations

import copy
from email import policy
from email.parser import BytesParser
from email.header import decode_header, make_header
import io
import json
import os
import re
import shutil
import threading
import uuid
import zipfile
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from .provider import build_prompt

ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = Path(os.environ.get("PRINT_STUDIO_DATA", ROOT / ".local-data"))
PRODUCT_ROOT = DATA_ROOT / "products"
OUTPUT_ROOT = DATA_ROOT / "outputs"
TEMPLATE_FILE = DATA_ROOT / "templates.json"
JOB_FILE = DATA_ROOT / "jobs.json"
SAMPLE_ROOT = Path(os.environ.get("PRINT_STUDIO_SAMPLE_DIR", ROOT / "data" / "samples"))
STATIC_ROOT = ROOT / "print_studio" / "static"
DIST_ROOT = ROOT / "dist"

PARTS = [
    {"id": "01", "name": "领子", "role": "collar", "mode": "strip", "x": 140, "y": 10, "w": 1018, "h": 113, "source_w": 579, "source_h": 64},
    {"id": "02", "name": "左门襟", "role": "left-placket", "mode": "strip", "x": 10, "y": 150, "w": 70, "h": 707, "source_w": 47, "source_h": 475},
    {"id": "03", "name": "右门襟", "role": "right-placket", "mode": "strip", "x": 100, "y": 150, "w": 70, "h": 709, "source_w": 47, "source_h": 476},
    {"id": "04", "name": "左口袋", "role": "left-pocket", "mode": "square", "x": 200, "y": 330, "w": 130, "h": 130, "source_w": 90, "source_h": 105},
    {"id": "05", "name": "后片", "role": "back", "mode": "square", "x": 360, "y": 150, "w": 440, "h": 440, "source_w": 338, "source_h": 375},
    {"id": "06", "name": "左前片", "role": "left-front", "mode": "portrait", "x": 830, "y": 150, "w": 330, "h": 440, "source_w": 145, "source_h": 371},
    {"id": "07", "name": "右口袋", "role": "right-pocket", "mode": "square", "x": 10, "y": 900, "w": 160, "h": 160, "source_w": 92, "source_h": 106},
    {"id": "08", "name": "右前片", "role": "right-front", "mode": "portrait", "x": 200, "y": 670, "w": 240, "h": 320, "source_w": 150, "source_h": 369},
    {"id": "09", "name": "左袖", "role": "left-sleeve", "mode": "square", "x": 470, "y": 670, "w": 300, "h": 300, "source_w": 222, "source_h": 241},
    {"id": "10", "name": "右袖", "role": "right-sleeve", "mode": "square", "x": 800, "y": 670, "w": 360, "h": 360, "source_w": 220, "source_h": 240},
    {"id": "11", "name": "左袖口", "role": "left-cuff", "mode": "landscape", "x": 720, "y": 1090, "w": 200, "h": 150, "source_w": 133, "source_h": 64},
    {"id": "12", "name": "右袖口", "role": "right-cuff", "mode": "landscape", "x": 960, "y": 1090, "w": 200, "h": 150, "source_w": 131, "source_h": 62},
]
DEFAULT_TEMPLATE = {
    "id": "confirmed-12-part",
    "name": "12块针织上衣模板",
    "confirmed": True,
    "created_at": "2026-10-28T00:00:00Z",
    "updated_at": "2026-10-28T00:00:00Z",
    "left_right": "wearer-anatomical",
    "parts": PARTS,
    "notes": [
        "裁片布局图只用于定位、数量、方向和比例，不作为印花参考。",
        "长条四周各扩充原尺寸10%，保持原内容比例并补画，不拉伸。",
        "图3仅作尺码参考，不单独生成。",
    ],
}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ensure_data() -> None:
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    PRODUCT_ROOT.mkdir(parents=True, exist_ok=True)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    if not TEMPLATE_FILE.exists():
        TEMPLATE_FILE.write_text(json.dumps([DEFAULT_TEMPLATE], ensure_ascii=False, indent=2), encoding="utf-8")
    if not JOB_FILE.exists():
        JOB_FILE.write_text("[]\n", encoding="utf-8")


def read_json(path: Path, fallback):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return copy.deepcopy(fallback)


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def export_size(part: dict) -> list[int]:
    mode = part.get("mode", "portrait")
    if mode == "square":
        return [1536, 1536]
    if mode == "landscape":
        return [2048, 1536]
    if mode == "portrait":
        return [1536, 2048]
    sw, sh = max(1, int(part.get("source_w", part.get("w", 1)))), max(1, int(part.get("source_h", part.get("h", 1))))
    short = 1536
    return [round(short * sw / sh), short] if sw >= sh else [short, round(short * sh / sw)]


def normalize_template(template: dict) -> dict:
    result = copy.deepcopy(template)
    result.setdefault("id", f"template-{uuid.uuid4().hex[:8]}")
    result.setdefault("name", "未命名模板")
    result.setdefault("confirmed", False)
    result.setdefault("left_right", "wearer-anatomical")
    result["parts"] = [dict(part, export_size_px=export_size(part), name_editable=True, role_mapping_editable=True) for part in result.get("parts", [])]
    result["updated_at"] = now()
    return result


def templates() -> list[dict]:
    ensure_data()
    values = read_json(TEMPLATE_FILE, [DEFAULT_TEMPLATE])
    if not values:
        values = [DEFAULT_TEMPLATE]
    return [normalize_template(item) for item in values]


def jobs() -> list[dict]:
    ensure_data()
    return read_json(JOB_FILE, [])


def save_templates(values: list[dict]) -> None:
    write_json(TEMPLATE_FILE, values)


def save_jobs(values: list[dict]) -> None:
    write_json(JOB_FILE, values)


def sample_manifest() -> dict:
    materials = SAMPLE_ROOT / "materials"
    parts = []
    if materials.exists():
        for path in sorted(materials.glob("*.jpg")):
            parts.append({"filename": path.name, "available": True, "size_bytes": path.stat().st_size})
    if not parts:
        parts = [{"filename": f"{part['id']}-{part['role']}.jpg", "available": False, "size_px": export_size(part)} for part in PARTS]
    return {"available": any(item.get("available") for item in parts), "status": "12-part visual test; review before production", "parts": parts}


def layout_svg(template: dict, clean: bool = False) -> str:
    colors = {"strip": ("#f5ead5", "#b8843b"), "square": ("#e3f0e9", "#4d8771"), "portrait": ("#e6eef9", "#5475a9"), "landscape": ("#eee8fa", "#8064ab")}
    parts = template.get("parts", PARTS)
    svg = ["<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1200 1300' role='img'>", "<rect width='1200' height='1300' fill='#fbfbf7'/>"]
    for part in parts:
        fill, stroke = colors.get(part.get("mode"), colors["portrait"])
        x, y, w, h = [float(part.get(key, 0)) for key in ("x", "y", "w", "h")]
        svg.append(f"<rect class='part' data-id='{part['id']}' x='{x:g}' y='{y:g}' width='{w:g}' height='{h:g}' rx='12' fill='{fill}' stroke='{stroke}' stroke-width='3'/>")
        if part.get("mode") == "strip":
            svg.append(f"<rect x='{x+w/12:g}' y='{y+h/12:g}' width='{w*5/6:g}' height='{h*5/6:g}' fill='none' stroke='{stroke}' stroke-dasharray='8 7' stroke-width='2'/>")
        if not clean:
            svg.append(f"<text x='{x+w/2:g}' y='{y+h/2:g}' text-anchor='middle' dominant-baseline='middle' font-family='Arial,sans-serif' font-size='{max(14, min(30, w/8)):g}' font-weight='700' fill='#25334a'>{part['id']}</text>")
    svg.append("</svg>")
    return "".join(svg)


def layout_jpg(template: dict, clean: bool = False) -> bytes:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        return layout_svg(template, clean).encode("utf-8")
    image = Image.new("RGB", (1200, 1300), "#fbfbf7")
    draw = ImageDraw.Draw(image)
    font_paths = [Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"), Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")]
    font_path = next((path for path in font_paths if path.exists()), None)
    font = ImageFont.truetype(str(font_path), 24) if font_path else ImageFont.load_default()
    colors = {"strip": ("#f5ead5", "#b8843b"), "square": ("#e3f0e9", "#4d8771"), "portrait": ("#e6eef9", "#5475a9"), "landscape": ("#eee8fa", "#8064ab")}
    for part in template.get("parts", PARTS):
        fill, stroke = colors.get(part.get("mode"), colors["portrait"])
        x, y, w, h = [int(float(part.get(key, 0))) for key in ("x", "y", "w", "h")]
        draw.rounded_rectangle((x, y, x + w, y + h), radius=12, fill=fill, outline=stroke, width=3)
        if part.get("mode") == "strip":
            ix, iy, iw, ih = int(x + w / 12), int(y + h / 12), int(w * 5 / 6), int(h * 5 / 6)
            draw.rectangle((ix, iy, ix + iw, iy + ih), outline=stroke, width=2)
        if not clean:
            label = str(part.get("id", ""))
            bbox = draw.textbbox((0, 0), label, font=font)
            draw.text((x + w / 2 - (bbox[2] - bbox[0]) / 2, y + h / 2 - (bbox[3] - bbox[1]) / 2), label, fill="#25334a", font=font)
    output = io.BytesIO(); image.save(output, format="JPEG", quality=94, subsampling=0); return output.getvalue()


def write_preview_artifacts() -> None:
    ensure_data()
    (DATA_ROOT / "layout-numbered.svg").write_text(layout_svg(DEFAULT_TEMPLATE), encoding="utf-8")
    (DATA_ROOT / "layout-clean.svg").write_text(layout_svg(DEFAULT_TEMPLATE, clean=True), encoding="utf-8")
    (DATA_ROOT / "layout-numbered.jpg").write_bytes(layout_jpg(DEFAULT_TEMPLATE))
    (DATA_ROOT / "layout-clean.jpg").write_bytes(layout_jpg(DEFAULT_TEMPLATE, clean=True))


def decode_filename(value: str | None) -> str:
    if not value:
        return "upload"
    try:
        return str(make_header(decode_header(value)))
    except Exception:
        return value


class Handler(BaseHTTPRequestHandler):
    server_version = "PrintMaterialStudio/1.0"

    def log_message(self, fmt, *args):
        if os.environ.get("PRINT_STUDIO_QUIET") != "1":
            super().log_message(fmt, *args)

    def send_json(self, value, status=200):
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, body: bytes, content_type: str, status=200, disposition: str | None = None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        if disposition:
            self.send_header("Content-Disposition", f'attachment; filename="{disposition}"')
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self):
        ensure_data()
        parsed = urlparse(self.path)
        path = parsed.path
        if path in ("/", "/index.html"):
            return self.serve_file(STATIC_ROOT / "index.html", "text/html; charset=utf-8")
        if path == "/preview.html":
            return self.serve_file(DIST_ROOT / "preview.html", "text/html; charset=utf-8")
        if path.startswith("/static/"):
            target = STATIC_ROOT / path.removeprefix("/static/")
            return self.serve_file(target)
        if path == "/api/status":
            return self.send_json({"configured": bool(os.environ.get("OPENAI_API_KEY")), "model": os.environ.get("PRINT_STUDIO_MODEL", "gpt-image-2.5"), "mode": "server", "api_key_in_frontend": False})
        if path == "/api/templates":
            return self.send_json(templates())
        if path == "/api/products":
            products = []
            for folder in sorted(PRODUCT_ROOT.iterdir() if PRODUCT_ROOT.exists() else []):
                if folder.is_dir():
                    meta = read_json(folder / "meta.json", {})
                    files = [p.name for p in sorted(folder.iterdir()) if p.is_file() and p.name != "meta.json"]
                    products.append({"id": folder.name, "name": meta.get("name") or folder.name, "files": files, "front": meta.get("front") or (files[0] if files else None), "back": meta.get("back") or (files[1] if len(files) > 1 else None)})
            return self.send_json(products)
        match = re.match(r"^/api/products/([^/]+)/(.+)$", path)
        if match:
            product_id, filename = match.group(1), Path(unquote(match.group(2))).name
            candidate = PRODUCT_ROOT / product_id / filename
            content_type = {".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".png":"image/png", ".webp":"image/webp"}.get(candidate.suffix.lower(), "application/octet-stream")
            return self.serve_file(candidate, content_type)
        if path == "/api/jobs":
            return self.send_json(jobs())
        if path == "/api/samples":
            return self.send_json(sample_manifest())
        if path.startswith("/api/samples/file/"):
            name = Path(path.removeprefix("/api/samples/file/")).name
            candidate = (SAMPLE_ROOT / 'materials' / name) if (SAMPLE_ROOT / 'materials' / name).exists() else (SAMPLE_ROOT / name)
            return self.serve_file(candidate, "image/jpeg")
        if path == "/api/download/template-preview":
            write_preview_artifacts(); return self.send_bytes((DATA_ROOT / "layout-numbered.jpg").read_bytes(), "image/jpeg", disposition="layout-numbered.jpg")
        if path == "/api/download/layout-clean":
            write_preview_artifacts(); return self.send_bytes((DATA_ROOT / "layout-clean.jpg").read_bytes(), "image/jpeg", disposition="layout-clean.jpg")
        if path == "/api/download/samples.zip":
            return self.send_bytes(self.make_zip(), "application/zip", disposition="print-material-samples.zip")
        return self.send_json({"error": "not_found"}, 404)

    def serve_file(self, path: Path, content_type: str | None = None):
        if not path.is_file():
            return self.send_json({"error": "not_found", "path": str(path)}, 404)
        body = path.read_bytes()
        if not content_type:
            content_type = {".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".html": "text/html; charset=utf-8", ".svg": "image/svg+xml", ".json": "application/json"}.get(path.suffix, "application/octet-stream")
        return self.send_bytes(body, content_type)

    def do_POST(self):
        ensure_data()
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/templates":
            incoming = normalize_template(self.read_json())
            values = templates()
            values = [item for item in values if item.get("id") != incoming["id"]]
            values.append(incoming)
            save_templates(values)
            return self.send_json(incoming, 201)
        if path == "/api/templates/analyze":
            template = copy.deepcopy(DEFAULT_TEMPLATE)
            template["id"] = f"draft-{uuid.uuid4().hex[:8]}"
            template["name"] = "新上传布局草稿"
            template["confirmed"] = False
            return self.send_json({"template": normalize_template(template), "message": "已生成编号空白布局，请逐块核对后确认"}, 201)
        if path == "/api/products":
            return self.handle_products_upload()
        if path == "/api/handoff/package":
            payload = self.read_json()
            template_id = payload.get("template_id", DEFAULT_TEMPLATE["id"])
            part_id = str(payload.get("part_id", "08"))
            template = next((item for item in templates() if item.get("id") == template_id), DEFAULT_TEMPLATE)
            part = next((item for item in template.get("parts", []) if item.get("id") == part_id), PARTS[7])
            products = payload.get("product_ids", [])
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("manifest.json", json.dumps({"workflow":"ChatGPT manual handoff","template_id":template_id,"part_id":part_id,"part":part,"product_ids":products,"visible_area_rule":"保留可见像素，只对遮挡区域局部补全","image_reference_rule":"只使用商品效果图，不使用裁片布局图花纹"}, ensure_ascii=False, indent=2))
                archive.writestr("prompt.txt", build_prompt(part, texture=bool(payload.get("texture")), mirror=bool(payload.get("mirror"))))
                for product_id in products:
                    folder = PRODUCT_ROOT / Path(product_id).name
                    if folder.is_dir():
                        for image in folder.iterdir():
                            if image.is_file() and image.name != "meta.json": archive.write(image, f"products/{product_id}/{image.name}")
            return self.send_bytes(buffer.getvalue(), "application/zip", disposition=f"chatgpt-task-{part_id}.zip")
        if path == "/api/handoff/import":
            return self.handle_handoff_import()
        if path == "/api/jobs":
            if not os.environ.get("OPENAI_API_KEY"):
                return self.send_json({"error": "missing_api_key", "message": "未配置本机 API 密钥，生成任务已阻止"}, 409)
            payload = self.read_json()
            template_id = payload.get("template_id", DEFAULT_TEMPLATE["id"])
            job = {"id": f"job-{uuid.uuid4().hex[:10]}", "created_at": now(), "status": "queued", "template_id": template_id, "products": payload.get("product_ids", []), "parts": [{"id": p["id"], "name": p["name"], "status": "queued", "attempts": 0} for p in PARTS], "note": "已入队；实际模型调用由本机 provider 配置决定"}
            values = jobs(); values.insert(0, job); save_jobs(values)
            return self.send_json(job, 201)
        match = re.match(r"^/api/jobs/([^/]+)/cancel$", path)
        if match:
            values = jobs(); job = next((item for item in values if item.get("id") == match.group(1)), None)
            if not job: return self.send_json({"error": "not_found"}, 404)
            job["status"] = "cancelled"; job["updated_at"] = now(); save_jobs(values)
            return self.send_json(job)
        match = re.match(r"^/api/jobs/([^/]+)/parts/([^/]+)/retry$", path)
        if match:
            values = jobs(); job = next((item for item in values if item.get("id") == match.group(1)), None)
            if not job: return self.send_json({"error": "not_found"}, 404)
            for part in job.get("parts", []):
                if part.get("id") == match.group(2): part.update(status="queued", attempts=part.get("attempts", 0) + 1)
            job["status"] = "queued"; job["updated_at"] = now(); save_jobs(values)
            return self.send_json(job)
        return self.send_json({"error": "not_found"}, 404)

    def handle_products_upload(self):
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in content_type:
            return self.send_json({"error": "multipart_required"}, 400)
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        envelope = (f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n").encode("utf-8") + raw
        message = BytesParser(policy=policy.default).parsebytes(envelope)
        group = "商品批次"
        uploads = []
        for part in message.iter_parts():
            disposition = part.get("Content-Disposition", "")
            field_name = part.get_param("name", header="content-disposition")
            filename = part.get_filename()
            if field_name == "group" and not filename:
                group = (part.get_content() or "商品批次").strip() or "商品批次"
            elif field_name == "photos" and filename:
                uploads.append((decode_filename(filename), part.get_payload(decode=True) or b""))
        product_id = f"product-{uuid.uuid4().hex[:8]}"
        folder = PRODUCT_ROOT / product_id; folder.mkdir(parents=True, exist_ok=True)
        files = []
        for filename, payload in uploads:
            safe = Path(filename).name
            target = folder / safe
            target.write_bytes(payload)
            files.append(safe)
        meta = {"id": product_id, "name": group, "files": files, "front": files[0] if files else None, "back": files[1] if len(files) > 1 else None}
        (folder / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return self.send_json(meta, 201)

    def handle_handoff_import(self):
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in content_type:
            return self.send_json({"error": "multipart_required"}, 400)
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        envelope = (f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n").encode("utf-8") + raw
        message = BytesParser(policy=policy.default).parsebytes(envelope)
        part_id = "08"; uploaded = None; filename = "result.jpg"
        for item in message.iter_parts():
            field = item.get_param("name", header="content-disposition")
            if field == "part_id" and not item.get_filename(): part_id = (item.get_content() or "08").strip()
            if field in ("result", "image") and item.get_filename():
                filename = decode_filename(item.get_filename()); uploaded = item.get_payload(decode=True) or b""
        if not uploaded: return self.send_json({"error":"missing_result"},400)
        safe = Path(filename).name; target = OUTPUT_ROOT / f"part-{part_id}-{safe}"; target.write_bytes(uploaded)
        return self.send_json({"part_id":part_id,"filename":target.name,"size_bytes":len(uploaded),"status":"imported"},201)

    def make_zip(self) -> bytes:
        write_preview_artifacts()
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("layout-numbered.jpg", (DATA_ROOT / "layout-numbered.jpg").read_bytes())
            archive.writestr("layout-clean.jpg", (DATA_ROOT / "layout-clean.jpg").read_bytes())
            archive.writestr("manifest.json", json.dumps({"parts": PARTS, "format": "JPG", "status": "review required"}, ensure_ascii=False, indent=2))
            if (SAMPLE_ROOT / "materials").exists():
                for path in sorted((SAMPLE_ROOT / "materials").glob("*.jpg")):
                    archive.write(path, f"materials/{path.name}")
            else:
                archive.writestr("materials/README.txt", "当前环境没有已生成样品；配置 API 后可从任务页生成。\n")
        return buffer.getvalue()


def serve(host="127.0.0.1", port=8765):
    ensure_data(); write_preview_artifacts()
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"Print Material Studio running at http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    serve(host=os.environ.get("PRINT_STUDIO_HOST", "127.0.0.1"), port=int(os.environ.get("PRINT_STUDIO_PORT", "8765")))
