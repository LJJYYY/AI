from __future__ import annotations

import copy
from email import policy
from email.parser import BytesParser
from email.header import decode_header, make_header
import io
import hashlib
import json
import os
import re
import shutil
import threading
import uuid
import zipfile
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from .provider import build_prompt
from .texture import rebuild_surface
from .layout_analysis import detect_layout_regions

ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = Path(os.environ.get("PRINT_STUDIO_DATA", ROOT / ".local-data"))
PRODUCT_ROOT = DATA_ROOT / "products"
OUTPUT_ROOT = DATA_ROOT / "outputs"
LAYOUT_ROOT = DATA_ROOT / "template-layouts"
TEMPLATE_FILE = DATA_ROOT / "templates.json"
JOB_FILE = DATA_ROOT / "jobs.json"
SETTINGS_FILE = DATA_ROOT / "settings.json"
SAMPLE_ROOT = Path(os.environ.get("PRINT_STUDIO_SAMPLE_DIR", ROOT / "data" / "samples"))
STATIC_ROOT = ROOT / "print_studio" / "static"
DIST_ROOT = ROOT / "dist"
BUILD_VERSION = "layout-runs-v2"

PARTS = [
    {"id": "01", "name": "领子", "role": "collar", "mode": "strip", "x": 140, "y": 10, "w": 1018, "h": 113, "source_w": 579, "source_h": 64},
    {"id": "02", "name": "左门襟", "role": "left-placket", "mode": "strip", "x": 10, "y": 150, "w": 70, "h": 707, "source_w": 47, "source_h": 475},
    {"id": "03", "name": "右门襟", "role": "right-placket", "mode": "strip", "x": 100, "y": 150, "w": 70, "h": 709, "source_w": 47, "source_h": 476},
    {"id": "04", "name": "左口袋", "role": "left-pocket", "mode": "square", "x": 200, "y": 330, "w": 130, "h": 130, "source_w": 90, "source_h": 105},
    {"id": "05", "name": "后片", "role": "back", "mode": "square", "x": 360, "y": 150, "w": 440, "h": 440, "source_w": 338, "source_h": 375},
    {"id": "06", "name": "左前片", "role": "left-front", "mode": "portrait", "x": 830, "y": 150, "w": 330, "h": 440, "source_w": 145, "source_h": 371},
    {"id": "07", "name": "右口袋", "role": "right-pocket", "mode": "square", "x": 10, "y": 900, "w": 160, "h": 160, "source_w": 92, "source_h": 106},
    {"id": "08", "name": "右前片", "role": "right-front", "mode": "portrait", "x": 200, "y": 670, "w": 240, "h": 320, "source_w": 150, "source_h": 369},
    {"id": "09", "name": "左袖", "role": "left-sleeve", "mode": "square", "x": 470, "y": 670, "w": 300, "h": 300, "source_w": 222, "source_h": 241},
    {"id": "10", "name": "右袖", "role": "right-sleeve", "mode": "square", "x": 800, "y": 670, "w": 360, "h": 360, "source_w": 220, "source_h": 240},
    {"id": "11", "name": "左袖口", "role": "left-cuff", "mode": "landscape", "x": 720, "y": 1090, "w": 200, "h": 150, "source_w": 133, "source_h": 64},
    {"id": "12", "name": "右袖口", "role": "right-cuff", "mode": "landscape", "x": 960, "y": 1090, "w": 200, "h": 150, "source_w": 131, "source_h": 62},
]
DEFAULT_TEMPLATE = {
    "id": "confirmed-12-part",
    "name": "12块针织上衣模板",
    "confirmed": True,
    "created_at": "2026-10-28T00:00:00Z",
    "updated_at": "2026-10-28T00:00:00Z",
    "left_right": "wearer-anatomical",
    "parts": PARTS,
    "notes": [
        "裁片布局图只用于定位、数量、方向和比例，不作为印花参考。",
        "长条四周各扩充原尺寸10%，保持原内容比例并补画，不拉伸。",
        "图3仅作尺码参考，不单独生成。",
    ],
}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ensure_data() -> None:
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    PRODUCT_ROOT.mkdir(parents=True, exist_ok=True)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    LAYOUT_ROOT.mkdir(parents=True, exist_ok=True)
    if not TEMPLATE_FILE.exists():
        TEMPLATE_FILE.write_text(json.dumps([DEFAULT_TEMPLATE], ensure_ascii=False, indent=2), encoding="utf-8")
    if not JOB_FILE.exists():
        JOB_FILE.write_text("[]\n", encoding="utf-8")


def read_json(path: Path, fallback):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return copy.deepcopy(fallback)


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _positive_int(value, fallback: int = 1) -> int:
    try:
        parsed = int(float(value))
    except (TypeError, ValueError):
        parsed = fallback
    return max(1, parsed)


def _nonnegative_int(value, fallback: int = 0) -> int:
    try:
        parsed = int(float(value))
    except (TypeError, ValueError):
        parsed = fallback
    return max(0, parsed)


def export_size(part: dict) -> list[int]:
    mode = part.get("mode", "portrait")
    if mode == "square":
        return [1536, 1536]
    if mode == "landscape":
        return [2048, 1536]
    if mode == "portrait":
        return [1536, 2048]
    sw = _positive_int(part.get("source_w", part.get("w", 1)))
    sh = _positive_int(part.get("source_h", part.get("h", 1)))
    short = 1536
    return [round(short * sw / sh), short] if sw >= sh else [short, round(short * sh / sw)]


def normalize_part(part: dict, index: int = 0) -> dict:
    result = copy.deepcopy(part or {})
    default_id = f"{index + 1:02d}"
    result["id"] = str(result.get("id") or default_id)
    result["name"] = str(result.get("name") or f"裁片 {result['id']}").strip()
    result["role"] = str(result.get("role") or f"piece-{result['id']}").strip()
    result["mode"] = result.get("mode") if result.get("mode") in {"strip", "square", "portrait", "landscape"} else "portrait"
    result["x"] = _nonnegative_int(result.get("x"), 0)
    result["y"] = _nonnegative_int(result.get("y"), 0)
    result["w"] = _positive_int(result.get("w"), 1)
    result["h"] = _positive_int(result.get("h"), 1)
    result["source_w"] = _positive_int(result.get("source_w", result["w"]))
    result["source_h"] = _positive_int(result.get("source_h", result["h"]))
    result["mirror"] = bool(result.get("mirror", False))
    result["mirrorSource"] = str(result.get("mirrorSource", result.get("mirror_source", "")) or "")
    result.pop("mirror_source", None)
    result["keepTexture"] = bool(result.get("keepTexture", result.get("keep_texture", False)))
    result.pop("keep_texture", None)
    result["export_size_px"] = export_size(result)
    result["name_editable"] = True
    result["role_mapping_editable"] = True
    return result


def normalize_template(template: dict, *, touch: bool = False) -> dict:
    result = copy.deepcopy(template or {})
    if not result.get("id"):
        result["id"] = f"template-{uuid.uuid4().hex[:8]}"
    result["name"] = str(result.get("name") or "未命名模板").strip() or "未命名模板"
    result.setdefault("confirmed", False)
    result.setdefault("left_right", "wearer-anatomical")
    result.setdefault("created_at", now())
    result.setdefault("updated_at", result.get("created_at") or now())
    if touch:
        result["updated_at"] = now()
    result["parts"] = [normalize_part(part, index) for index, part in enumerate(result.get("parts") or [])]
    return result

def unique_template_names(values: list[dict]) -> tuple[list[dict], bool]:
    used: set[str] = set()
    changed = False
    result: list[dict] = []
    for index, item in enumerate(values):
        entry = copy.deepcopy(item)
        base = str(entry.get("name") or f"未命名模板 {index + 1}").strip() or f"未命名模板 {index + 1}"
        name = base
        suffix = 2
        while name.casefold() in used:
            name = f"{base} {suffix}"
            suffix += 1
        if entry.get("name") != name:
            entry["name"] = name
            changed = True
        used.add(name.casefold())
        result.append(entry)
    return result, changed


def templates() -> list[dict]:
    ensure_data()
    values = read_json(TEMPLATE_FILE, [DEFAULT_TEMPLATE])
    if not values:
        values = [DEFAULT_TEMPLATE]
    values, changed = unique_template_names(values)
    if changed:
        save_templates(values)
    return [normalize_template(item) for item in values]


def jobs() -> list[dict]:
    ensure_data()
    return read_json(JOB_FILE, [])


def app_settings() -> dict:
    ensure_data()
    value = read_json(SETTINGS_FILE, {})
    return value if isinstance(value, dict) else {}


def effective_api_key() -> str:
    return os.environ.get("OPENAI_API_KEY", "") or str(app_settings().get("api_key", ""))


def save_templates(values: list[dict]) -> None:
    write_json(TEMPLATE_FILE, values)


def save_jobs(values: list[dict]) -> None:
    write_json(JOB_FILE, values)


def sample_manifest() -> dict:
    materials = SAMPLE_ROOT / "materials"
    parts = []
    if materials.exists():
        for path in sorted(materials.glob("*.jpg")):
            parts.append({"filename": path.name, "available": True, "size_bytes": path.stat().st_size})
    if not parts:
        parts = [{"filename": f"{part['id']}-{part['role']}.jpg", "available": False, "size_px": export_size(part)} for part in PARTS]
    return {"available": any(item.get("available") for item in parts), "status": "12-part visual test; review before production", "parts": parts}


def layout_svg(template: dict, clean: bool = False) -> str:
    colors = {"strip": ("#f5ead5", "#b8843b"), "square": ("#e3f0e9", "#4d8771"), "portrait": ("#e6eef9", "#5475a9"), "landscape": ("#eee8fa", "#8064ab")}
    parts = template.get("parts", PARTS)
    svg = ["<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1200 1300' role='img'>", "<rect width='1200' height='1300' fill='#fbfbf7'/>"]
    for part in parts:
        fill, stroke = colors.get(part.get("mode"), colors["portrait"])
        x, y, w, h = [float(part.get(key, 0)) for key in ("x", "y", "w", "h")]
        svg.append(f"<rect class='part' data-id='{part['id']}' x='{x:g}' y='{y:g}' width='{w:g}' height='{h:g}' rx='12' fill='{fill}' stroke='{stroke}' stroke-width='3'/>")
        if part.get("mode") == "strip":
            svg.append(f"<rect x='{x+w/12:g}' y='{y+h/12:g}' width='{w*5/6:g}' height='{h*5/6:g}' fill='none' stroke='{stroke}' stroke-dasharray='8 7' stroke-width='2'/>")
        if not clean:
            svg.append(f"<text x='{x+w/2:g}' y='{y+h/2:g}' text-anchor='middle' dominant-baseline='middle' font-family='Arial,sans-serif' font-size='{max(14, min(30, w/8)):g}' font-weight='700' fill='#25334a'>{part['id']}</text>")
    svg.append("</svg>")
    return "".join(svg)


def layout_jpg(template: dict, clean: bool = False) -> bytes:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        return layout_svg(template, clean).encode("utf-8")
    image = Image.new("RGB", (1200, 1300), "#fbfbf7")
    draw = ImageDraw.Draw(image)
    font_paths = [Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"), Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")]
    font_path = next((path for path in font_paths if path.exists()), None)
    font = ImageFont.truetype(str(font_path), 24) if font_path else ImageFont.load_default()
    colors = {"strip": ("#f5ead5", "#b8843b"), "square": ("#e3f0e9", "#4d8771"), "portrait": ("#e6eef9", "#5475a9"), "landscape": ("#eee8fa", "#8064ab")}
    for part in template.get("parts", PARTS):
        fill, stroke = colors.get(part.get("mode"), colors["portrait"])
        x, y, w, h = [int(float(part.get(key, 0))) for key in ("x", "y", "w", "h")]
        draw.rounded_rectangle((x, y, x + w, y + h), radius=12, fill=fill, outline=stroke, width=3)
        if part.get("mode") == "strip":
            ix, iy, iw, ih = int(x + w / 12), int(y + h / 12), int(w * 5 / 6), int(h * 5 / 6)
            draw.rectangle((ix, iy, ix + iw, iy + ih), outline=stroke, width=2)
        if not clean:
            label = str(part.get("id", ""))
            bbox = draw.textbbox((0, 0), label, font=font)
            draw.text((x + w / 2 - (bbox[2] - bbox[0]) / 2, y + h / 2 - (bbox[3] - bbox[1]) / 2), label, fill="#25334a", font=font)
    output = io.BytesIO(); image.save(output, format="JPEG", quality=94, subsampling=0); return output.getvalue()


def write_preview_artifacts(template: dict | None = None) -> None:
    ensure_data()
    template = template or DEFAULT_TEMPLATE
    (DATA_ROOT / "layout-numbered.svg").write_text(layout_svg(template), encoding="utf-8")
    (DATA_ROOT / "layout-clean.svg").write_text(layout_svg(template, clean=True), encoding="utf-8")
    (DATA_ROOT / "layout-numbered.jpg").write_bytes(layout_jpg(template))
    (DATA_ROOT / "layout-clean.jpg").write_bytes(layout_jpg(template, clean=True))



def _layout_mask_components(data: bytes):
    # Compatibility helper; boxes are now in original-image coordinates.
    regions, metadata = detect_layout_regions(data)
    return regions, metadata['width'], metadata['height']


def template_parts_from_layout(data: bytes) -> tuple[list[dict], dict]:
    components, metadata = detect_layout_regions(data)
    sw, sh = metadata['width'], metadata['height']
    scale = min(1120 / sw, 1230 / sh)
    offset_x, offset_y = (1200 - sw * scale) / 2, (1300 - sh * scale) / 2
    parts = []
    for index, (left, top, right, bottom, _area) in enumerate(components):
        width, height = max(1, right-left), max(1, bottom-top)
        ratio = width / height
        mode = 'strip' if ratio >= 3 or ratio <= 1/3 else 'landscape' if ratio >= 1.18 else 'portrait' if ratio <= .84 else 'square'
        part_id = f'{index+1:02d}'
        parts.append(normalize_part(dict(id=part_id, name=f'裁片 {part_id}', role=f'piece-{part_id}', mode=mode,
            x=round(offset_x+left*scale), y=round(offset_y+top*scale), w=max(1,round(width*scale)), h=max(1,round(height*scale)),
            source_w=width, source_h=height, source_box=[left,top,right,bottom]),index))
    return parts, metadata


def decode_filename(value: str | None) -> str:
    if not value:
        return "upload"
    try:
        return str(make_header(decode_header(value)))
    except Exception:
        return value


class Handler(BaseHTTPRequestHandler):
    server_version = "PrintMaterialStudio/1.0"

    def log_message(self, fmt, *args):
        if os.environ.get("PRINT_STUDIO_QUIET") != "1":
            super().log_message(fmt, *args)

    def send_json(self, value, status=200):
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, body: bytes, content_type: str, status=200, disposition: str | None = None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        if disposition:
            self.send_header("Content-Disposition", f'attachment; filename="{disposition}"')
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self):
        ensure_data()
        parsed = urlparse(self.path)
        path = parsed.path
        if path in ("/", "/index.html"):
            return self.serve_file(STATIC_ROOT / "index.html", "text/html; charset=utf-8")
        if path == "/preview.html":
            return self.serve_file(DIST_ROOT / "preview.html", "text/html; charset=utf-8")
        if path == "/favicon.ico":
            self.send_response(204); self.end_headers(); return
        if path.startswith("/static/"):
            target = STATIC_ROOT / path.removeprefix("/static/")
            return self.serve_file(target)
        if path == "/api/status":
            settings = app_settings()
            return self.send_json({"configured": bool(effective_api_key()), "model": settings.get("model") or os.environ.get("PRINT_STUDIO_MODEL", "gpt-image-2.5"), "daily_calls": settings.get("daily_calls", 40), "daily_budget": settings.get("daily_budget", 20), "mode": "server", "build": BUILD_VERSION, "api_key_in_frontend": False})
        if path == "/api/settings":
            settings = app_settings()
            return self.send_json({"configured": bool(effective_api_key()), "model": settings.get("model") or os.environ.get("PRINT_STUDIO_MODEL", "gpt-image-2.5"), "daily_calls": settings.get("daily_calls", 40), "daily_budget": settings.get("daily_budget", 20)})
        if path == "/api/templates":
            return self.send_json(templates())
        source_match = re.match(r"^/api/templates/([^/]+)/source$", path)
        if source_match:
            template_id = Path(unquote(source_match.group(1))).name
            template = next((item for item in templates() if item.get("id") == template_id), None)
            stored_name = ((template or {}).get("layout_source") or {}).get("stored_name")
            if not stored_name and re.fullmatch(r"draft-[a-f0-9]+",template_id):
                existing = next(LAYOUT_ROOT.glob(template_id+".*"),None)
                stored_name = existing.name if existing else None
            if not stored_name:
                return self.send_json({"error": "not_found"}, 404)
            candidate = LAYOUT_ROOT / Path(stored_name).name
            suffix = candidate.suffix.lower()
            content_type = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".bmp": "image/bmp"}.get(suffix, "application/octet-stream")
            return self.serve_file(candidate, content_type)
        if path == "/api/products":
            products = []
            for folder in sorted(PRODUCT_ROOT.iterdir() if PRODUCT_ROOT.exists() else []):
                if folder.is_dir():
                    meta = read_json(folder / "meta.json", {})
                    files = [p.name for p in sorted(folder.iterdir()) if p.is_file() and p.name != "meta.json"]
                    products.append({"id": folder.name, "name": meta.get("name") or folder.name, "files": files, "front": meta.get("front") or (files[0] if files else None), "back": meta.get("back") or (files[1] if len(files) > 1 else None), "template_id": meta.get("template_id"), "template_name": meta.get("template_name")})
            return self.send_json(products)
        match = re.match(r"^/api/products/([^/]+)/(.+)$", path)
        if match:
            product_id, filename = match.group(1), Path(unquote(match.group(2))).name
            candidate = PRODUCT_ROOT / product_id / filename
            content_type = {".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".png":"image/png", ".webp":"image/webp"}.get(candidate.suffix.lower(), "application/octet-stream")
            return self.serve_file(candidate, content_type)
        if path == "/api/materials":
            tid = parse_qs(parsed.query).get("template_id", [""])[0]
            values = [read_json(p, {}) for p in OUTPUT_ROOT.glob("material-*/meta.json")]
            return self.send_json([v for v in values if v and (not tid or v.get("template_id") == tid)])
        material_match = re.fullmatch(r"/api/materials/(material-[a-f0-9]+)/(?P<action>preview|download)", path)
        if material_match:
            folder = OUTPUT_ROOT / material_match.group(1)
            meta = read_json(folder / "meta.json", {})
            if not meta: return self.send_json({"message":"素材不存在"},404)
            if material_match.group('action') == 'download':
                if meta.get('status') != 'approved':
                    return self.send_json({"message":"先完成遮挡补全并审核，草稿不能作为正式素材导出"},409)
                return self.send_bytes((folder / "material.jpg").read_bytes(),"image/jpeg",disposition=f"{meta['part_id']}-material.jpg")
            return self.serve_file(folder / "draft.png", "image/png")
        if path == "/api/jobs":
            return self.send_json(jobs())
        if path == "/api/samples":
            return self.send_json(sample_manifest())
        if path.startswith("/api/samples/file/"):
            name = Path(path.removeprefix("/api/samples/file/")).name
            candidate = (SAMPLE_ROOT / 'materials' / name) if (SAMPLE_ROOT / 'materials' / name).exists() else (SAMPLE_ROOT / name)
            return self.serve_file(candidate, "image/jpeg")
        if path == "/api/download/template-preview":
            template_id = parse_qs(parsed.query).get("template_id", [""])[0]
            template = next((item for item in templates() if item.get("id") == template_id), DEFAULT_TEMPLATE)
            write_preview_artifacts(template); return self.send_bytes((DATA_ROOT / "layout-numbered.jpg").read_bytes(), "image/jpeg", disposition="layout-numbered.jpg")
        if path == "/api/download/layout-clean":
            template_id = parse_qs(parsed.query).get("template_id", [""])[0]
            template = next((item for item in templates() if item.get("id") == template_id), DEFAULT_TEMPLATE)
            write_preview_artifacts(template); return self.send_bytes((DATA_ROOT / "layout-clean.jpg").read_bytes(), "image/jpeg", disposition="layout-clean.jpg")
        if path == "/api/download/samples.zip":
            template_id = parse_qs(parsed.query).get("template_id", [""])[0]
            template = next((item for item in templates() if item.get("id") == template_id), DEFAULT_TEMPLATE)
            return self.send_bytes(self.make_zip(template), "application/zip", disposition="print-material-samples.zip")
        return self.send_json({"error": "not_found"}, 404)

    def serve_file(self, path: Path, content_type: str | None = None):
        if not path.is_file():
            return self.send_json({"error": "not_found", "path": str(path)}, 404)
        body = path.read_bytes()
        if not content_type:
            content_type = {".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".html": "text/html; charset=utf-8", ".svg": "image/svg+xml", ".json": "application/json"}.get(path.suffix, "application/octet-stream")
        return self.send_bytes(body, content_type)

    def do_DELETE(self):
        ensure_data()
        parsed = urlparse(self.path)
        match = re.match(r"^/api/templates/([^/]+)$", parsed.path)
        if not match:
            return self.send_json({"error": "not_found"}, 404)
        template_id = Path(unquote(match.group(1))).name
        values = templates()
        target = next((item for item in values if item.get("id") == template_id), None)
        if not target:
            return self.send_json({"error": "not_found", "message": "模板不存在"}, 404)
        if len(values) <= 1:
            return self.send_json({"error": "last_template", "message": "至少保留一个模板"}, 409)
        save_templates([item for item in values if item.get("id") != template_id])
        stored_name = (target.get("layout_source") or {}).get("stored_name")
        if stored_name:
            try:
                (LAYOUT_ROOT / Path(stored_name).name).unlink(missing_ok=True)
            except OSError:
                pass
        return self.send_json({"id": template_id, "deleted": True})

    def do_POST(self):
        ensure_data()
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/materials/prepare":
            try:
                payload = self.read_json()
                template = next(t for t in templates() if t['id'] == payload['template_id'])
                part = next(p for p in template['parts'] if p['id'] == payload['part_id'])
                product_id = str(payload['product_id'])
                if not re.fullmatch(r"product-[a-zA-Z0-9-]+", product_id): raise ValueError('商品标识无效')
                folder = PRODUCT_ROOT / product_id
                meta = read_json(folder / "meta.json", {})
                if meta.get('template_id') != template['id']: raise ValueError('商品与模板不匹配，请选择该商品绑定的模板')
                filename = payload.get('filename') or meta.get('front')
                if filename not in meta.get('files', []): raise ValueError('商品图不存在')
                from PIL import Image, ImageOps
                with Image.open(folder / Path(filename).name) as opened:
                    source = ImageOps.exif_transpose(opened).convert('RGB')
                quad = [float(v) for v in payload['quad']]
                result, mask, report = rebuild_surface(source,quad,tuple(export_size(part)),payload.get('exclusions',[]),payload.get('repairs',[]))
                material_id = 'material-' + uuid.uuid4().hex[:12]
                target = OUTPUT_ROOT / material_id; target.mkdir()
                result.save(target / 'draft.png')
                mask.save(target / 'valid-mask.png')
                record = dict(id=material_id,template_id=template['id'],template_name=template['name'],product_id=product_id,part_id=part['id'],part_name=part['name'],size_px=list(result.size),created_at=now(),plan=payload,**report)
                write_json(target / 'meta.json', record)
                return self.send_json(record,201)
            except (KeyError,StopIteration,TypeError,ValueError,OSError) as error:
                return self.send_json({'message':str(error) or '部件或模板不存在'},400)
        material_match = re.fullmatch(r"/api/materials/(material-[a-f0-9]+)/approve", path)
        if material_match:
            folder = OUTPUT_ROOT / material_match.group(1)
            record = read_json(folder / 'meta.json', {})
            if not record: return self.send_json({'message':'素材不存在'},404)
            if record.get('unresolved_pixels',1):
                return self.send_json({'message':'仍有未补全区域，请完成遮挡补全后审核'},409)
            from PIL import Image
            with Image.open(folder / 'draft.png') as image:
                image.convert('RGB').save(folder / 'material.jpg',quality=96,subsampling=0)
            record['status']='approved';write_json(folder/'meta.json',record)
            return self.send_json(record)
        if path == "/api/settings":
            try:
                payload = self.read_json()
            except (TypeError, ValueError, json.JSONDecodeError):
                return self.send_json({"error": "invalid_settings", "message": "设置数据格式不正确"}, 400)
            settings = app_settings()
            api_key = str(payload.get("api_key", "")).strip()
            if api_key:
                settings["api_key"] = api_key
            if payload.get("clear_api_key"):
                settings.pop("api_key", None)
            if payload.get("model"):
                settings["model"] = str(payload["model"]).strip()
            for field in ("daily_calls", "daily_budget"):
                if field in payload:
                    settings[field] = payload[field]
            write_json(SETTINGS_FILE, settings)
            return self.send_json({"configured": bool(effective_api_key()), "model": settings.get("model") or "gpt-image-2.5", "daily_calls": settings.get("daily_calls", 40), "daily_budget": settings.get("daily_budget", 20)})
        if path == "/api/templates":
            try:
                incoming = normalize_template(self.read_json(), touch=True)
            except (TypeError, ValueError, json.JSONDecodeError):
                return self.send_json({"error": "invalid_template", "message": "模板数据格式不正确"}, 400)
            values = templates()
            name = (incoming.get("name") or "未命名模板").strip()
            duplicate = next((item for item in values if item.get("id") != incoming["id"] and (item.get("name") or "").strip().casefold() == name.casefold()), None)
            if duplicate:
                return self.send_json({"error": "duplicate_template_name", "message": f"模板名称已存在：{name}"}, 409)
            if incoming.get("confirmed") and not incoming.get("parts"):
                return self.send_json({"message":"没有候选裁片，无法确认布局。请先成功分析布局图。"},400)
            incoming["name"] = name
            incoming.pop("isDraft", None)
            incoming.pop("dirty", None)
            values = [item for item in values if item.get("id") != incoming["id"]]
            values.append(incoming)
            save_templates(values)
            return self.send_json(incoming, 201)
        if path == "/api/templates/analyze":
            return self.handle_template_analyze()
        if path == "/api/products":
            return self.handle_products_upload()
        if path == "/api/handoff/package":
            payload = self.read_json()
            template_id = payload.get("template_id", DEFAULT_TEMPLATE["id"])
            part_id = str(payload.get("part_id", "08"))
            template = next((item for item in templates() if item.get("id") == template_id), DEFAULT_TEMPLATE)
            part = next((item for item in template.get("parts", []) if item.get("id") == part_id), PARTS[7])
            products = payload.get("product_ids", [])
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
                manifest={"workflow":"ChatGPT manual handoff","template_id":template_id,"template_name":template.get("name"),"part_id":part_id,"part":part,"product_ids":products,"visible_area_rule":"保留可见像素，只对遮挡区域局部补全","image_reference_rule":"只使用商品效果图，不使用裁片布局图花纹","forbidden":"禁止把原图窄条裁切、手、内搭、背景或褶皱导出为成品","output":"仅输出当前部件的平面矩形 JPG"}
                archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
                archive.writestr("template.json", json.dumps(template, ensure_ascii=False, indent=2))
                archive.writestr("part.json", json.dumps(part, ensure_ascii=False, indent=2))
                archive.writestr("prompt.txt", build_prompt(part, texture=bool(payload.get("texture")), mirror=bool(payload.get("mirror"))))
                archive.writestr("instructions.txt", "请直接按 prompt.txt 执行当前部件；不要再次询问花纹来源、是否重绘或是否使用布局图花纹。商品图只用于识别可见花纹，布局图不作为图案参考。\n")
                for product_id in products:
                    folder = PRODUCT_ROOT / Path(product_id).name
                    if folder.is_dir():
                        for image in folder.iterdir():
                            if image.is_file() and image.name != "meta.json": archive.write(image, f"products/{product_id}/{image.name}")
            return self.send_bytes(buffer.getvalue(), "application/zip", disposition=f"chatgpt-task-{part_id}.zip")
        if path == "/api/handoff/import":
            return self.handle_handoff_import()
        if path == "/api/jobs":
            return self.send_json({"error":"surface_mapping_required", "message":"自动整件重建尚未接通。请先使用下方“部件展开与遮挡补全”生成可审核草稿，不能用原图裁切代替成品。"},409)
            if not effective_api_key():
                return self.send_json({"error": "missing_api_key", "message": "未配置本机 API 密钥，生成任务已阻止"}, 409)
            payload = self.read_json()
            template_id = payload.get("template_id", DEFAULT_TEMPLATE["id"])
            template = next((item for item in templates() if item.get("id") == template_id), DEFAULT_TEMPLATE)
            job = {"id": f"job-{uuid.uuid4().hex[:10]}", "created_at": now(), "status": "queued", "template_id": template_id, "products": payload.get("product_ids", []), "parts": [{"id": p["id"], "name": p["name"], "status": "queued", "attempts": 0} for p in template.get("parts", PARTS)], "note": "已入队；实际模型调用由本机 provider 配置决定"}
            values = jobs(); values.insert(0, job); save_jobs(values)
            return self.send_json(job, 201)
        match = re.match(r"^/api/jobs/([^/]+)/cancel$", path)
        if match:
            values = jobs(); job = next((item for item in values if item.get("id") == match.group(1)), None)
            if not job: return self.send_json({"error": "not_found"}, 404)
            job["status"] = "cancelled"; job["updated_at"] = now(); save_jobs(values)
            return self.send_json(job)
        match = re.match(r"^/api/jobs/([^/]+)/parts/([^/]+)/retry$", path)
        if match:
            values = jobs(); job = next((item for item in values if item.get("id") == match.group(1)), None)
            if not job: return self.send_json({"error": "not_found"}, 404)
            for part in job.get("parts", []):
                if part.get("id") == match.group(2): part.update(status="queued", attempts=part.get("attempts", 0) + 1)
            job["status"] = "queued"; job["updated_at"] = now(); save_jobs(values)
            return self.send_json(job)
        return self.send_json({"error": "not_found"}, 404)

    def handle_template_analyze(self):
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in content_type:
            return self.send_json({"error": "multipart_required", "message": "请上传裁片布局图片"}, 400)
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        envelope = (f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n").encode("utf-8") + raw
        message = BytesParser(policy=policy.default).parsebytes(envelope)
        filename = "layout-image"
        requested_template_id = ""
        uploaded = None
        for item in message.iter_parts():
            field = item.get_param("name", header="content-disposition")
            if field == "template_id" and not item.get_filename():
                requested_template_id = (item.get_content() or "").strip()
            if field in ("layout", "image", "file") and item.get_filename():
                filename = decode_filename(item.get_filename())
                uploaded = item.get_payload(decode=True) or b""
        if not uploaded:
            return self.send_json({"error": "missing_layout", "message": "没有收到布局图片"}, 400)
        template_id = requested_template_id if requested_template_id.startswith("draft-") else f"draft-{uuid.uuid4().hex[:10]}"
        suffix = Path(filename).suffix.lower()
        if suffix not in {".jpg", ".jpeg", ".png", ".webp", ".bmp"}:
            suffix = ".bin"
        stored_name = f"{template_id}{suffix}"
        (LAYOUT_ROOT / stored_name).write_bytes(uploaded)
        try:
            parts, metadata = template_parts_from_layout(uploaded)
        except Exception:
            (LAYOUT_ROOT / stored_name).unlink(missing_ok=True)
            return self.send_json({"error": "invalid_layout", "message": "布局文件无法读取，请上传 JPG、PNG 或 WEBP 图片"}, 400)
        template = {}
        template.update({
            "id": template_id,
            "name": Path(filename).stem,
            "confirmed": False,
            "created_at": now(),
            "updated_at": now(),
            "parts": parts,
            "isDraft": True,
            "dirty": True,
        })
        template["layout_source"] = {
            "filename": filename,
            "stored_name": stored_name,
            "url": f"/api/templates/{template_id}/source",
            **metadata,
        }
        template = normalize_template(template, touch=True)
        existing_templates = [item for item in templates() if item["id"] != template_id]
        template = unique_template_names(existing_templates + [template])[0][-1]
        detected = metadata.get("detected_count", 0)
        if detected:
            message_text = f"已载入布局图，检测到 {detected} 个候选部件；请核对、命名后保存模板"
        else:
            message_text = "图片已载入，但本地分析未能分离出裁片。未套用旧模板；请核对背景和部件间的间隙。"
        return self.send_json({"template": template, "message": message_text}, 201)

    def handle_products_upload(self):
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in content_type:
            return self.send_json({"error": "multipart_required"}, 400)
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        envelope = (f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n").encode("utf-8") + raw
        message = BytesParser(policy=policy.default).parsebytes(envelope)
        group = "商品批次"
        template_id = ""
        uploads = []
        for part in message.iter_parts():
            disposition = part.get("Content-Disposition", "")
            field_name = part.get_param("name", header="content-disposition")
            filename = part.get_filename()
            if field_name == "group" and not filename:
                group = (part.get_content() or "商品批次").strip() or "商品批次"
            elif field_name == "template_id" and not filename:
                template_id = (part.get_content() or "").strip()
            elif field_name == "photos" and filename:
                uploads.append((decode_filename(filename), part.get_payload(decode=True) or b""))
        if not uploads:
            return self.send_json({"error":"missing_photos","message":"没有收到图片文件"},400)
        incoming_hashes = {hashlib.sha256(payload).hexdigest() for _, payload in uploads}
        for existing_folder in PRODUCT_ROOT.iterdir() if PRODUCT_ROOT.exists() else []:
            if not existing_folder.is_dir(): continue
            existing_meta = read_json(existing_folder / "meta.json", {})
            existing_hashes = set(existing_meta.get("sha256", []))
            if not existing_hashes:
                for existing_file in existing_folder.iterdir():
                    if existing_file.is_file() and existing_file.name != "meta.json":
                        existing_hashes.add(hashlib.sha256(existing_file.read_bytes()).hexdigest())
            if incoming_hashes & existing_hashes:
                return self.send_json({"error":"duplicate_product","message":"检测到重复上传的商品图片，已跳过"},409)
        product_id = f"product-{uuid.uuid4().hex[:8]}"
        folder = PRODUCT_ROOT / product_id; folder.mkdir(parents=True, exist_ok=True)
        files = []
        for filename, payload in uploads:
            safe = Path(filename).name
            target = folder / safe
            target.write_bytes(payload)
            files.append(safe)
        template = next((item for item in templates() if item.get("id") == template_id), None)
        meta = {"id": product_id, "name": group, "files": files, "front": files[0] if files else None, "back": files[1] if len(files) > 1 else None, "sha256": [hashlib.sha256(payload).hexdigest() for _, payload in uploads], "template_id": template_id or None, "template_name": template.get("name") if template else None}
        (folder / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return self.send_json(meta, 201)

    def handle_handoff_import(self):
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in content_type:
            return self.send_json({"error": "multipart_required"}, 400)
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        envelope = (f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n").encode("utf-8") + raw
        message = BytesParser(policy=policy.default).parsebytes(envelope)
        part_id = "08"; uploaded = None; filename = "result.jpg"
        for item in message.iter_parts():
            field = item.get_param("name", header="content-disposition")
            if field == "part_id" and not item.get_filename(): part_id = (item.get_content() or "08").strip()
            if field in ("result", "image") and item.get_filename():
                filename = decode_filename(item.get_filename()); uploaded = item.get_payload(decode=True) or b""
        if not uploaded: return self.send_json({"error":"missing_result"},400)
        safe = Path(filename).name; target = OUTPUT_ROOT / f"part-{part_id}-{safe}"; target.write_bytes(uploaded)
        return self.send_json({"part_id":part_id,"filename":target.name,"size_bytes":len(uploaded),"status":"imported"},201)

    def make_zip(self, template: dict | None = None) -> bytes:
        write_preview_artifacts(template)
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("layout-numbered.jpg", (DATA_ROOT / "layout-numbered.jpg").read_bytes())
            archive.writestr("layout-clean.jpg", (DATA_ROOT / "layout-clean.jpg").read_bytes())
            archive.writestr("manifest.json", json.dumps({"template_id":(template or DEFAULT_TEMPLATE)['id'],"parts": (template or DEFAULT_TEMPLATE)['parts'], "format": "JPG", "status": "only approved materials included"}, ensure_ascii=False, indent=2))
            for meta_file in OUTPUT_ROOT.glob("material-*/meta.json"):
                meta = read_json(meta_file, {})
                if meta.get('template_id') == (template or DEFAULT_TEMPLATE)['id'] and meta.get('status') == 'approved':
                    archive.write(meta_file.parent / 'material.jpg', f"materials/{meta['product_id']}/{meta['part_id']}-{meta['id']}.jpg")
            if (SAMPLE_ROOT / "materials").exists():
                for path in sorted((SAMPLE_ROOT / "materials").glob("*.jpg")):
                    archive.write(path, f"materials/{path.name}")
            else:
                archive.writestr("materials/README.txt", "当前环境没有已生成样品；配置 API 后可从任务页生成。\n")
        return buffer.getvalue()


def serve(host="127.0.0.1", port=8765):
    ensure_data(); write_preview_artifacts()
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"Print Material Studio running at http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    serve(host=os.environ.get("PRINT_STUDIO_HOST", "127.0.0.1"), port=int(os.environ.get("PRINT_STUDIO_PORT", "8765")))
