Option Explicit
Dim shell, root
Set shell = CreateObject("WScript.Shell")
root = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = root
shell.Run "cmd /c """ & root & "\start-windows.bat""", 0, False
WScript.Sleep 1200
shell.Run "http://127.0.0.1:18765", 1, False
